# V13 左手搬运力控保持补丁

原始 V13 在 `handoff_B/C/A_left_grasp` 只调用一次阻塞式 `grasp_force(1.0)`。
后续 `place_B/C/A` 只控制左臂，未再次刷新左手力控。部分 SDK/仿真实现会在原语
返回后退回关节位置保持，螺母可能在移动过程中滑落。

补丁行为：

- `place_B`、`place_C`、`place_A` 第一个有效控制周期立即调用
  `left_hand.grasp_force(strength=1.0, fingers=None, blocking=False)`。
- 此后每 8 个控制周期刷新一次，2 Hz 下约每 4 秒一次。
- `release_B/C/A` 不刷新力控，仍按 V13 原逻辑张开左手。
- 不改变轨迹、手指目标、A/B/C 坐标、模型或其他阶段。

运行日志应周期性出现：

```text
"event": "left_force_hold_refreshed"
"stage": "place_B"
"strength": 1.0
"blocking": false
```
