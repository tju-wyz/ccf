# V13 原版自动验收

本目录来自原始 `rabo_hierarchy_ep01_team_bundle_v13.zip`，没有包含 V14A-V14G
的 A 下移、相机降级、preform 重试、自动校准或预摆臂反馈逻辑。

相对原始 V13 只增加：

1. `sensors_ready` 后等待 10 秒再执行原始 V13 策略，用来替代以前人工输入命令产生的等待。
2. 每个 official episode 完成或失败后，先 `stop()` 和 `shutdown()` 设备 SDK，
   释放 ROS action server，再进入 idle，避免下一次启动出现多个同名 action server。

正式运行仍要求平台根目录存在 V13 的三个固定关节文件：

```text
C_GRASP_Z_MINUS_008_JOINTS.json
A_GRASP_WORLD_Y_MINUS_005_JOINTS.json
A_LIFT_WORLD_Y_MINUS_005_JOINTS.json
```

启动日志应显示 `official_autorun=true`、`actuation_enabled=true`，随后出现：

```text
sensors_ready
official_actuation_delay
stage_start: pre_position
```

一局结束后的 `official_run_idle` 应显示 `action_servers_released=true`。
首次测试前必须完整停止旧仿真和旧 Agent，确保此前残留的 ROS 节点已退出。
