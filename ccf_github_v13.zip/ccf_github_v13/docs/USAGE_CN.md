# 部署与使用方法

## 1. 平台要求

- Rabo 仿真模式；
- Python 3.12 环境；
- ROS2 相机和关节话题可用；
- `rabo_robocap` 2.0.7 附近版本；
- `rabo-dev-kit` 1.2 附近版本；
- 平台启动命令能够执行根目录 `main.py`。

安装依赖：

```bash
python3 -m pip install -r requirements.txt
```

不要把 `setuptools` 升级到 80 或更高；ROS2 的 `colcon-core` 与之不兼容。项目将 NumPy 固定为 1.26.4，OpenCV 限制在 5 以下。

## 2. 必需文件

平台 Agent 根目录至少需要：

```text
main.py
config.yaml
requirements.txt
agents/rabo_hierarchy_agent/
drivers/
rabo_bc/
models/hierarchy_ep01.pt
C_GRASP_Z_MINUS_008_JOINTS.json
A_GRASP_WORLD_Y_MINUS_005_JOINTS.json
A_LIFT_WORLD_Y_MINUS_005_JOINTS.json
```

`config.yaml` 中的世界、双臂、双手、相机和 ROS topic ID 必须与目标平台场景一致。

## 3. 正式自动运行

当前版本默认：

```text
RABO_MODE=sim
RABO_SENSOR_BACKEND=ros2
RABO_OFFICIAL_AUTORUN=1
RABO_HIERARCHY_DEVICE=cpu
```

启动仿真后平台执行：

```bash
python3 -u main.py
```

不需要创建 `RUN_HIERARCHY_EP01_ONCE`。校准文件齐全时，程序等待传感器就绪，再延迟 10 秒自动开始执行。

正常启动日志应包含：

```text
"official_autorun": true
"actuation_enabled": true
"a_grasp_joint_override_loaded": true
"a_lift_joint_override_loaded": true
"c_grasp_joint_override_loaded": true
```

如果出现 `actuation_locked`，通常表示校准文件缺失、文件名错误，或配置没有加载成功。

## 4. 单次手动测试

若关闭自动运行，可设置：

```bash
export RABO_OFFICIAL_AUTORUN=0
touch RUN_HIERARCHY_EP01_ONCE
python3 -u main.py
```

程序会把请求文件改名为 `.hierarchy_ep01_claimed`，避免同一请求重复执行。Windows 本地只用于代码检查，实际 ROS2 仿真命令应在 Rabo Linux 终端运行。

## 5. 重复验收

每轮任务结束后会进入 `official_run_idle`，同时尝试停止设备并释放 action client。下一轮应停止并重新启动仿真/Agent 进程，使场景和 ROS2 节点重新初始化。

不要在上一进程仍执行动作时启动第二个 Agent。若看到：

```text
Ignoring unexpected goal response
There may be more than one action server
```

说明旧进程或 SDK 节点尚未完全释放。应停止所有相关仿真与 Agent，等待数秒后只启动一个实例。

## 6. 常见故障

### 仿真无动作但持续输出预测

检查启动日志中的 `actuation_enabled`。若为 `false`，当前处于影子模式，只推理不发送动作。

### `stale_image`

相机长时间没有新帧。先确认仿真没有暂停，再检查对应相机 topic。高负载时可以降低画质或排查平台资源，但不建议直接取消安全检查。

### 预摆臂不收敛

SDK 返回成功不一定表示读取状态时机械臂已经完全到位。先降低仿真启动负载，确保只存在一个 Agent 实例。当前整理版本保持平台实际使用的 V13 行为，没有加入未在平台验证的等待收敛补丁。

### 手部动作超时

检查是否发生碰撞、手指是否已到限位，以及 SDK 是否仍在处理上一条阻塞命令。释放动作允许有限残差，抓取和预成形仍使用严格检查。

### 搬运时螺母掉落

当前版本会在 `place_B/C/A` 阶段刷新左手 `grasp_force`。应检查日志中的 `left_force_hold_refreshed`，并确认左手在交接时已形成稳定包络抓取。

## 7. 本地测试

有 pytest 环境时执行：

```bash
python3 -m pip install -r requirements-dev.txt
python3 -m pytest -q
```

这些测试主要覆盖阻塞式机械臂回放、设备范围选择、手部抓取/释放原语与力保持逻辑，不替代 Rabo 仿真集成测试。

若本地提示 `No module named 'torch'`，说明只安装了轻量 Python 环境，还没有安装项目依赖；这不是代码测试失败。Rabo 平台部署环境会按根目录 `requirements.txt` 安装依赖。

## 8. GitHub 发布建议

1. 先建私有仓库并推送本整理目录；
2. 检查 `config.yaml` 和固定场景坐标是否允许公开；
3. 大型原始数据集不要直接提交 Git；
4. 若以后上传大模型，使用 Git LFS 或 Release；
5. 在提交信息中注明版本为 `v13-official-repeat-left-force-hold`。
