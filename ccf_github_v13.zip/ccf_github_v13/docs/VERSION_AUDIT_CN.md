# 版本审计与文件整理

## 1. 判定结论

`E:\ccf` 当前实际生效版本为：

```text
V13 official repeat + left force hold
```

不是 V14。

判定依据是平台当前文件与历史补丁包逐字节哈希比对：

| 文件 | 当前 SHA-256 | 完全匹配的补丁 |
|---|---|---|
| `agents/rabo_hierarchy_agent/controller.py` | `F9A8076465EADBC4086C2FFCF3EE818267555A3A3F7E977C9F464B6C5DCD5157` | `rabo_hierarchy_v13_left_force_hold_patch.zip` |
| `agents/rabo_hierarchy_agent/config.py` | `692F96636855473D900A3B17BAF003B4A94DDF5F558723BF61ADC47BE56FE77B` | `rabo_hierarchy_v13_left_force_hold_patch.zip` |

配置还明确引用 V13 文件：

```text
A_GRASP_WORLD_Y_MINUS_005_JOINTS.json
A_LIFT_WORLD_Y_MINUS_005_JOINTS.json
C_GRASP_Z_MINUS_008_JOINTS.json
```

它没有引用 V14A 的：

```text
A_GRASP_WORLD_Y_MINUS_005_Z_MINUS_004_JOINTS.json
A_LIFT_WORLD_Y_MINUS_005_Z_MINUS_004_JOINTS.json
```

代码中也没有 V14E/V14G 的自动 bootstrap 或基于仿真时钟的预摆臂 warmup 特征。

## 2. 整理原则

GitHub 整理目录以平台当前实际生效文件为唯一真值，不在整理过程中合并尚未验证的 V14 行为。

保留：

- 当前部署入口、控制器、驱动和模型推理代码；
- 当前实际加载的三个关节校准文件；
- `hierarchy_ep01.pt` 与训练摘要；
- 自动运行与左手力保持说明；
- 测试；
- 数据采集器源码，但不包含数据集；
- 早期 residual-BC 的训练/评估代码和关键结果，放入研究基线目录。

不复制：

- `__pycache__`、日志和运行 claim 文件；
- 所有历史补丁 zip；
- V14 专用校准 JSON；
- 原始视频、parquet 和大体积数据集；
- `rabo_minimal_bc` 中重复的压缩训练包；
- 平台模板中的示例 LLM Agent，与最终机器人策略无关。

## 3. 历史文件的含义

原始下载目录保留 V8 至 V14G 的补丁，是调试过程档案，不代表它们同时生效。补丁是覆盖式文件集合，最终版本必须以平台根目录当前同名文件为准，不能根据“最高版本号的 zip 仍存在”判断运行版本。

V14 系列曾尝试 A 抓取下降、自动校准、慢启动和仿真时钟 warmup，但用户随后要求恢复 V13 的动作行为，仅保留正式自动运行和资源释放。当前哈希验证与这一历史一致。

## 4. 可复现性边界

仓库包含：

- 最终检查点；
- 模型类和推理预处理；
- 运行控制器；
- 配置、阶段数据和训练摘要；
- residual-BC 基线训练代码。

仓库不包含分层 `hierarchy_ep01.pt` 的完整训练脚本，因此不能声称完全训练可复现。原始数据集仍保存在 `E:\ccf\dexora_rabo_collector_simple_v1\datasets`，未复制到 GitHub 整理目录。

## 5. 整理后的验证记录

- 当前控制器、配置和最终检查点 SHA-256 均与原始平台文件一致；
- 全部 Python 文件使用 Python 自身的编码识别规则完成语法检查；
- 当前 Windows 基础环境未安装 PyTorch，因此没有在该环境重新执行最终控制器 pytest；
- 历史采集器测试仍按旧单相机 `top` 配置编写，与保存的三相机采集配置不一致，不纳入默认测试范围；
- 之前在具备完整依赖的项目环境中，V13 左手力保持版本的最终控制器测试为 25 项通过。

上述记录区分了“整理过程的静态一致性验证”和“Rabo 平台集成验证”。真实机械臂、ROS2 topic、相机时效和仿真 action server 行为只能在 Rabo 环境中确认。
