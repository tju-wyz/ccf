from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from rabo_bc.data import PreparedActionChunkDataset
from rabo_bc.model import TinyVisualBC
from rabo_bc.normalization import denormalize_torch


def load_checkpoint(path: Path, device: torch.device) -> dict:
    try:
        return torch.load(path, map_location=device, weights_only=False)
    except TypeError:  # PyTorch 2.2 等旧版没有 weights_only 参数
        return torch.load(path, map_location=device)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="开放环评估BC checkpoint")
    parser.add_argument("--prepared-root", required=True, type=Path)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--split", choices=("train", "val"), default="val")
    parser.add_argument("--batch-size", default=64, type=int)
    parser.add_argument("--num-workers", default=2, type=int)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--output", default=None, type=Path)
    parser.add_argument(
        "--require-better-than-persistence",
        action="store_true",
        help="若模型不优于保持当前关节不动的基线，则以退出码2结束",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    device_name = args.device
    if device_name == "auto":
        device_name = "cuda" if torch.cuda.is_available() else "cpu"
    device = torch.device(device_name)
    payload = load_checkpoint(args.checkpoint, device)
    model = TinyVisualBC(**payload["model_config"]).to(device)
    model.load_state_dict(payload["model"])
    model.eval()
    stats = payload["normalization"]
    episode_indices = payload["split"][args.split]
    dataset = PreparedActionChunkDataset(
        args.prepared_root,
        episode_indices,
        payload["model_config"]["chunk_size"],
        stats,
        augment=False,
    )
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
    )

    total_abs = torch.zeros(model.action_dim, device=device)
    persistence_abs = torch.zeros(model.action_dim, device=device)
    first_abs = torch.zeros(model.action_dim, device=device)
    first_persistence_abs = torch.zeros(model.action_dim, device=device)
    step_abs = torch.zeros(model.chunk_size, device=device)
    step_persistence_abs = torch.zeros(model.chunk_size, device=device)
    scalar_count = 0
    step_scalar_count = 0
    first_count = 0
    command_jump_sum = 0.0
    target_jump_sum = 0.0
    command_jump_count = 0
    max_command_jump = 0.0
    nonfinite_predictions = 0
    command_jump_values = []
    target_jump_values = []
    episode_error_sums = {}
    episode_baseline_sums = {}
    episode_scalar_counts = {}
    with torch.inference_mode():
        for batch in loader:
            images = batch["images"].to(device)
            state = batch["state"].to(device)
            target = batch["actions"].to(device)
            prediction = model(images, state)
            nonfinite_predictions += int((~torch.isfinite(prediction)).sum().item())
            prediction = torch.nan_to_num(
                prediction, nan=0.0, posinf=1.0, neginf=-1.0
            )
            pred_rad = denormalize_torch(prediction, stats)
            target_rad = denormalize_torch(target, stats)
            state_rad = denormalize_torch(state, stats)
            error = (pred_rad - target_rad).abs()
            baseline = (state_rad[:, None, :] - target_rad).abs()
            first_error = error[:, 0]
            first_baseline = baseline[:, 0]
            command_jump = (pred_rad[:, 0] - state_rad).abs()
            target_jump = (target_rad[:, 0] - state_rad).abs()
            total_abs += error.sum(dim=(0, 1))
            persistence_abs += baseline.sum(dim=(0, 1))
            first_abs += first_error.sum(dim=0)
            first_persistence_abs += first_baseline.sum(dim=0)
            step_abs += error.sum(dim=(0, 2))
            step_persistence_abs += baseline.sum(dim=(0, 2))
            scalar_count += error.shape[0] * error.shape[1]
            step_scalar_count += error.shape[0] * error.shape[2]
            first_count += error.shape[0]
            command_jump_sum += command_jump.sum().item()
            target_jump_sum += target_jump.sum().item()
            command_jump_count += command_jump.numel()
            max_command_jump = max(max_command_jump, command_jump.max().item())
            command_jump_values.append(command_jump.detach().cpu().reshape(-1))
            target_jump_values.append(target_jump.detach().cpu().reshape(-1))
            sample_error = error.sum(dim=(1, 2)).detach().cpu().tolist()
            sample_baseline = baseline.sum(dim=(1, 2)).detach().cpu().tolist()
            sample_scalar_count = error.shape[1] * error.shape[2]
            for episode_index, error_sum, baseline_sum in zip(
                batch["episode_index"].tolist(), sample_error, sample_baseline
            ):
                episode_error_sums[episode_index] = (
                    episode_error_sums.get(episode_index, 0.0) + error_sum
                )
                episode_baseline_sums[episode_index] = (
                    episode_baseline_sums.get(episode_index, 0.0) + baseline_sum
                )
                episode_scalar_counts[episode_index] = (
                    episode_scalar_counts.get(episode_index, 0) + sample_scalar_count
                )

    per_joint = (total_abs / scalar_count).cpu().numpy()
    baseline_joint = (persistence_abs / scalar_count).cpu().numpy()
    first_per_joint = (first_abs / first_count).cpu().numpy()
    first_baseline_joint = (first_persistence_abs / first_count).cpu().numpy()
    per_step = (step_abs / step_scalar_count).cpu().numpy()
    persistence_per_step = (step_persistence_abs / step_scalar_count).cpu().numpy()
    group_slices = {
        "left_arm": slice(0, 7),
        "right_arm": slice(7, 14),
        "left_hand": slice(14, 20),
        "right_hand": slice(20, 26),
    }
    group_mae = {
        name: float(per_joint[indices].mean()) for name, indices in group_slices.items()
    }
    persistence_group_mae = {
        name: float(baseline_joint[indices].mean())
        for name, indices in group_slices.items()
    }
    group_improvement = {
        name: float(
            100.0
            * (
                1.0
                - group_mae[name] / max(persistence_group_mae[name], 1e-9)
            )
        )
        for name in group_slices
    }
    model_mae = float(per_joint.mean())
    persistence_mae = float(baseline_joint.mean())
    passes_baseline = nonfinite_predictions == 0 and model_mae < persistence_mae
    command_jump_values = torch.cat(command_jump_values)
    target_jump_values = torch.cat(target_jump_values)
    quantiles = torch.tensor([0.5, 0.95, 0.99, 1.0])
    command_jump_quantiles = torch.quantile(command_jump_values, quantiles).tolist()
    target_jump_quantiles = torch.quantile(target_jump_values, quantiles).tolist()
    per_episode = {}
    for episode_index in sorted(episode_scalar_counts):
        episode_model_mae = (
            episode_error_sums[episode_index] / episode_scalar_counts[episode_index]
        )
        episode_persistence_mae = (
            episode_baseline_sums[episode_index] / episode_scalar_counts[episode_index]
        )
        per_episode[str(episode_index)] = {
            "model_mae_rad": episode_model_mae,
            "persistence_mae_rad": episode_persistence_mae,
            "improvement_over_persistence_percent": 100.0
            * (
                1.0
                - episode_model_mae / max(episode_persistence_mae, 1e-9)
            ),
        }
    report = {
        "split": args.split,
        "checkpoint_epoch": payload.get("epoch"),
        "prediction_mode": payload["model_config"].get("prediction_mode", "absolute"),
        "episodes": episode_indices,
        "samples": len(dataset),
        "model_mae_rad": model_mae,
        "model_mae_degrees": float(np.degrees(model_mae)),
        "persistence_mae_rad": persistence_mae,
        "improvement_over_persistence_percent": float(
            100.0 * (1.0 - model_mae / max(persistence_mae, 1e-9))
        ),
        "passes_persistence_baseline": passes_baseline,
        "first_step_model_mae_rad": float(first_per_joint.mean()),
        "first_step_persistence_mae_rad": float(first_baseline_joint.mean()),
        "mean_first_command_jump_rad": command_jump_sum / command_jump_count,
        "mean_ground_truth_first_delta_rad": target_jump_sum / command_jump_count,
        "max_first_command_jump_rad": max_command_jump,
        "first_command_jump_quantiles_rad": dict(
            zip(("p50", "p95", "p99", "max"), command_jump_quantiles)
        ),
        "ground_truth_first_delta_quantiles_rad": dict(
            zip(("p50", "p95", "p99", "max"), target_jump_quantiles)
        ),
        "nonfinite_prediction_values": nonfinite_predictions,
        "per_episode": per_episode,
        "per_group_mae_rad": group_mae,
        "persistence_per_group_mae_rad": persistence_group_mae,
        "per_group_improvement_over_persistence_percent": group_improvement,
        "per_joint_mae_rad": per_joint.tolist(),
        "persistence_per_joint_mae_rad": baseline_joint.tolist(),
        "per_step_mae_rad": per_step.tolist(),
        "persistence_per_step_mae_rad": persistence_per_step.tolist(),
        "per_step_improvement_over_persistence_percent": (
            100.0
            * (1.0 - per_step / np.maximum(persistence_per_step, 1e-9))
        ).tolist(),
    }
    output = args.output or args.checkpoint.with_name(f"evaluation_{args.split}.json")
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if args.require_better_than_persistence and not passes_baseline:
        print("未通过：模型没有优于 persistence baseline，暂不建议闭环部署。")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
