from __future__ import annotations

import argparse
import csv
import json
import math
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from rabo_bc.data import (
    PreparedActionChunkDataset,
    load_episode_states,
    load_manifest,
    split_episode_indices,
)
from rabo_bc.model import TinyVisualBC
from rabo_bc.normalization import compute_percentile_stats, denormalize_torch


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="训练三相机26维动作块行为克隆策略")
    parser.add_argument("--prepared-root", required=True, type=Path)
    parser.add_argument("--output", default=Path("runs/bc_small"), type=Path)
    parser.add_argument("--chunk-size", default=8, type=int)
    parser.add_argument(
        "--prediction-mode",
        choices=("absolute", "residual"),
        default="residual",
        help="residual预测相对当前状态的增量，并以persistence为零输出基线",
    )
    parser.add_argument(
        "--first-step-weight",
        default=4.0,
        type=float,
        help="动作块第一步的损失权重；部署只执行第一步时应大于1",
    )
    parser.add_argument("--epochs", default=50, type=int)
    parser.add_argument("--batch-size", default=64, type=int)
    parser.add_argument("--learning-rate", default=3e-4, type=float)
    parser.add_argument("--weight-decay", default=1e-4, type=float)
    parser.add_argument("--val-fraction", default=0.2, type=float)
    parser.add_argument("--num-workers", default=2, type=int)
    parser.add_argument("--seed", default=42, type=int)
    parser.add_argument("--patience", default=10, type=int)
    parser.add_argument("--device", default="auto", choices=("auto", "cpu", "cuda"))
    parser.add_argument(
        "--overfit-episodes",
        default=0,
        type=int,
        help="大于0时只用前N条episode，训练/验证相同，用于检查管线能否过拟合",
    )
    parser.add_argument("--max-batches", default=0, type=int, help="冒烟测试时限制每轮batch数")
    return parser.parse_args()


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def choose_device(name: str) -> torch.device:
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if name == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("指定了CUDA，但torch.cuda.is_available()为False")
    return torch.device(name)


def make_loader(dataset, batch_size: int, workers: int, shuffle: bool) -> DataLoader:
    kwargs = {
        "dataset": dataset,
        "batch_size": batch_size,
        "shuffle": shuffle,
        "num_workers": workers,
        "pin_memory": torch.cuda.is_available(),
        "drop_last": shuffle and len(dataset) >= batch_size,
    }
    if workers > 0:
        kwargs["persistent_workers"] = True
        kwargs["prefetch_factor"] = 2
    return DataLoader(**kwargs)


def weighted_action_loss(
    prediction: torch.Tensor,
    target: torch.Tensor,
    first_step_weight: float,
) -> torch.Tensor:
    if first_step_weight < 1.0 or not math.isfinite(first_step_weight):
        raise ValueError("first_step_weight 必须是大于等于1的有限数")
    element_loss = F.smooth_l1_loss(
        prediction, target, beta=0.1, reduction="none"
    )
    step_weights = torch.ones(
        prediction.shape[1], dtype=prediction.dtype, device=prediction.device
    )
    step_weights[0] = first_step_weight
    weighted = element_loss * step_weights.view(1, -1, 1)
    denominator = prediction.shape[0] * prediction.shape[2] * step_weights.sum()
    return weighted.sum() / denominator


def run_epoch(
    model: TinyVisualBC,
    loader: DataLoader,
    device: torch.device,
    stats: dict,
    optimizer: torch.optim.Optimizer | None,
    scaler,
    max_batches: int,
    first_step_weight: float,
) -> dict[str, float]:
    training = optimizer is not None
    model.train(training)
    total_loss = total_mae = total_first_mae = total_persistence_mae = 0.0
    count = 0
    for batch_index, batch in enumerate(loader):
        if max_batches and batch_index >= max_batches:
            break
        images = batch["images"].to(device, non_blocking=True)
        state = batch["state"].to(device, non_blocking=True)
        target = batch["actions"].to(device, non_blocking=True)
        if training:
            optimizer.zero_grad(set_to_none=True)
        autocast_enabled = device.type == "cuda"
        with torch.autocast(device_type=device.type, enabled=autocast_enabled):
            prediction = model(images, state)
            loss = weighted_action_loss(prediction, target, first_step_weight)
        if training:
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()

        with torch.no_grad():
            pred_rad = denormalize_torch(prediction, stats)
            target_rad = denormalize_torch(target, stats)
            state_rad = denormalize_torch(state, stats)
            mae = (pred_rad - target_rad).abs().mean()
            first_mae = (pred_rad[:, 0] - target_rad[:, 0]).abs().mean()
            persistence_mae = (state_rad[:, None, :] - target_rad).abs().mean()
        batch_size = images.shape[0]
        total_loss += loss.detach().item() * batch_size
        total_mae += float(mae) * batch_size
        total_first_mae += float(first_mae) * batch_size
        total_persistence_mae += float(persistence_mae) * batch_size
        count += batch_size
    if count == 0:
        raise RuntimeError("本轮没有读取到batch")
    return {
        "loss": total_loss / count,
        "mae_rad": total_mae / count,
        "first_mae_rad": total_first_mae / count,
        "persistence_mae_rad": total_persistence_mae / count,
    }


def save_checkpoint(path: Path, model, stats, manifest, split, epoch, metrics) -> None:
    payload = {
        "model": model.state_dict(),
        "model_config": model.config_dict(),
        "normalization": stats,
        "data_config": {
            "camera_names": manifest["camera_names"],
            "state_names": manifest["state_names"],
            "target_fps": manifest["target_fps"],
            "image_width": manifest["image_width"],
            "image_height": manifest["image_height"],
        },
        "split": split,
        "epoch": epoch,
        "metrics": metrics,
    }
    torch.save(payload, path)


def main() -> int:
    args = parse_args()
    if args.first_step_weight < 1.0 or not math.isfinite(args.first_step_weight):
        raise ValueError("--first-step-weight 必须是大于等于1的有限数")
    seed_everything(args.seed)
    device = choose_device(args.device)
    args.output.mkdir(parents=True, exist_ok=True)
    manifest = load_manifest(args.prepared_root)
    episode_indices = [int(row["episode_index"]) for row in manifest["episodes"]]
    train_indices, val_indices = split_episode_indices(
        episode_indices, args.val_fraction, args.seed
    )
    if args.overfit_episodes:
        selected = sorted(episode_indices)[: args.overfit_episodes]
        train_indices = selected
        val_indices = selected

    train_states = [load_episode_states(args.prepared_root, i) for i in train_indices]
    stats = compute_percentile_stats(train_states)
    (args.output / "normalization.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    split = {"train": train_indices, "val": val_indices}
    (args.output / "split.json").write_text(
        json.dumps(split, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    train_dataset = PreparedActionChunkDataset(
        args.prepared_root,
        train_indices,
        args.chunk_size,
        stats,
        augment=not bool(args.overfit_episodes),
    )
    val_dataset = PreparedActionChunkDataset(
        args.prepared_root, val_indices, args.chunk_size, stats, augment=False
    )
    train_loader = make_loader(train_dataset, args.batch_size, args.num_workers, True)
    val_loader = make_loader(val_dataset, args.batch_size, args.num_workers, False)

    model = TinyVisualBC(
        num_cameras=len(manifest["camera_names"]),
        state_dim=int(manifest["state_dim"]),
        action_dim=int(manifest["state_dim"]),
        chunk_size=args.chunk_size,
        prediction_mode=args.prediction_mode,
    ).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(1, args.epochs)
    )
    # 新版优先使用 torch.amp；回退分支兼容较老的 PyTorch 2.x。
    try:
        scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    except (AttributeError, TypeError):
        scaler = torch.cuda.amp.GradScaler(enabled=device.type == "cuda")

    print(
        f"device={device}, train episodes={train_indices}, val episodes={val_indices}, "
        f"train samples={len(train_dataset)}, val samples={len(val_dataset)}, "
        f"prediction_mode={args.prediction_mode}, first_step_weight={args.first_step_weight:g}"
    )
    with torch.no_grad():
        initial_val_metrics = run_epoch(
            model,
            val_loader,
            device,
            stats,
            None,
            scaler,
            args.max_batches,
            args.first_step_weight,
        )
    best = initial_val_metrics["mae_rad"]
    stale_epochs = 0
    initial_metrics = {
        "epoch": 0,
        "val_mae_rad": initial_val_metrics["mae_rad"],
        "val_first_mae_rad": initial_val_metrics["first_mae_rad"],
        "val_persistence_mae_rad": initial_val_metrics["persistence_mae_rad"],
        "val_improvement_over_persistence_percent": 100.0
        * (
            1.0
            - initial_val_metrics["mae_rad"]
            / max(initial_val_metrics["persistence_mae_rad"], 1e-9)
        ),
    }
    save_checkpoint(
        args.output / "best.pt", model, stats, manifest, split, 0, initial_metrics
    )
    print(
        f"epoch 000 baseline | val mae {initial_metrics['val_mae_rad']:.4f} rad | "
        f"persistence {initial_metrics['val_persistence_mae_rad']:.4f} rad | "
        f"improvement {initial_metrics['val_improvement_over_persistence_percent']:+.1f}%"
    )
    history_path = args.output / "history.csv"
    with history_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "epoch",
                "lr",
                "train_loss",
                "train_mae_rad",
                "train_persistence_mae_rad",
                "val_loss",
                "val_mae_rad",
                "val_first_mae_rad",
                "val_persistence_mae_rad",
                "val_improvement_over_persistence_percent",
            ],
        )
        writer.writeheader()
        for epoch in range(1, args.epochs + 1):
            train_metrics = run_epoch(
                model,
                train_loader,
                device,
                stats,
                optimizer,
                scaler,
                args.max_batches,
                args.first_step_weight,
            )
            with torch.no_grad():
                val_metrics = run_epoch(
                    model,
                    val_loader,
                    device,
                    stats,
                    None,
                    scaler,
                    args.max_batches,
                    args.first_step_weight,
                )
            scheduler.step()
            row = {
                "epoch": epoch,
                "lr": optimizer.param_groups[0]["lr"],
                "train_loss": train_metrics["loss"],
                "train_mae_rad": train_metrics["mae_rad"],
                "train_persistence_mae_rad": train_metrics["persistence_mae_rad"],
                "val_loss": val_metrics["loss"],
                "val_mae_rad": val_metrics["mae_rad"],
                "val_first_mae_rad": val_metrics["first_mae_rad"],
                "val_persistence_mae_rad": val_metrics["persistence_mae_rad"],
                "val_improvement_over_persistence_percent": 100.0
                * (
                    1.0
                    - val_metrics["mae_rad"]
                    / max(val_metrics["persistence_mae_rad"], 1e-9)
                ),
            }
            writer.writerow(row)
            handle.flush()
            print(
                f"epoch {epoch:03d} | train loss {row['train_loss']:.5f} "
                f"mae {row['train_mae_rad']:.4f} rad | val loss {row['val_loss']:.5f} "
                f"mae {row['val_mae_rad']:.4f} rad | persistence "
                f"{row['val_persistence_mae_rad']:.4f} rad | improvement "
                f"{row['val_improvement_over_persistence_percent']:+.1f}%"
            )
            save_checkpoint(
                args.output / "last.pt", model, stats, manifest, split, epoch, row
            )
            if row["val_mae_rad"] < best:
                best = row["val_mae_rad"]
                stale_epochs = 0
                save_checkpoint(
                    args.output / "best.pt", model, stats, manifest, split, epoch, row
                )
            else:
                stale_epochs += 1
                if stale_epochs >= args.patience:
                    print(f"验证集连续{args.patience}轮未改善，提前停止")
                    break
    print(f"训练完成，最佳checkpoint：{args.output / 'best.pt'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
