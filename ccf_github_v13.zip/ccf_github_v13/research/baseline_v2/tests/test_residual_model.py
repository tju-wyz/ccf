from __future__ import annotations

import torch

from rabo_bc.model import TinyVisualBC
from train import weighted_action_loss


def test_residual_model_starts_at_persistence() -> None:
    model = TinyVisualBC(
        num_cameras=3,
        state_dim=26,
        action_dim=26,
        chunk_size=4,
        prediction_mode="residual",
    )
    images = torch.randn(2, 3, 3, 72, 128)
    state = torch.randn(2, 26)

    prediction = model(images, state)

    expected = state[:, None, :].expand(-1, 4, -1)
    torch.testing.assert_close(prediction, expected)
    assert model.config_dict()["prediction_mode"] == "residual"


def test_first_step_weight_changes_loss_emphasis() -> None:
    prediction = torch.zeros(1, 2, 1)
    target = torch.tensor([[[1.0], [0.0]]])

    uniform = weighted_action_loss(prediction, target, first_step_weight=1.0)
    emphasized = weighted_action_loss(prediction, target, first_step_weight=4.0)

    assert emphasized > uniform


def test_old_config_defaults_to_absolute_mode() -> None:
    model = TinyVisualBC(num_cameras=3, state_dim=26, action_dim=26, chunk_size=8)
    assert model.prediction_mode == "absolute"
