# RABO BC v2 residual 训练结果

## 关键修改

- 模型预测相对当前关节状态的 residual，零初始化时严格等于 persistence baseline。
- 动作块由 8 步缩短为 4 步，2 Hz 下覆盖未来 2 秒。
- 第一预测步使用 4 倍损失权重，与闭环部署只执行第一步的方式对齐。
- best.pt 按验证 MAE 选择，并保留 epoch 0 persistence 作为安全下限。
- 评估增加逐 episode、逐肢体、逐关节、逐步 baseline 和命令跳变分位数。
- 未包含 prediction_mode 的旧 checkpoint 仍按 absolute 模式加载。

## 训练命令

    .\.venv\Scripts\python.exe train.py --prepared-root prepared/rabo_3cam_2hz --output runs/rabo_bc_v2_residual4 --chunk-size 4 --prediction-mode residual --first-step-weight 4 --epochs 40 --patience 10 --batch-size 64 --num-workers 0 --device cuda

## 验证结果

    checkpoint epoch:                 40
    model MAE:                        0.015304 rad (0.877 deg)
    persistence MAE:                  0.029347 rad
    improvement over persistence:     47.85%
    first-step model MAE:             0.007673 rad
    first-step persistence MAE:       0.011859 rad
    first-step improvement:           35.30%
    non-finite predictions:           0

5 个验证 episode 全部优于 persistence，提升范围为 31.7% 到 58.1%。四个肢体分组也全部通过。

首步预测跳变的 p95/p99/max 为 0.065/0.170/0.464 rad，真值为
0.076/0.188/0.472 rad，没有发现模型异常放大。

## 部署边界

开放环指标已通过，但还不等于仿真闭环成功。首次接入 Rabo 时：

1. 每 0.5 秒重新观测和预测，只执行 4 步动作块的第一步。
2. 保留平台侧关节限位、速度限制、碰撞检测和急停。
3. 先在单条已见轨迹回放，再测 5 个验证 episode，最后测未见随机场景。
4. 当前 26 条数据没有螺母 C 尺寸版本标签，不能据此证明对不同尺寸的泛化。

验收命令：

    .\.venv\Scripts\python.exe evaluate.py --prepared-root prepared/rabo_3cam_2hz --checkpoint runs/rabo_bc_v2_residual4/best.pt --split val --batch-size 64 --num-workers 0 --device cuda --require-better-than-persistence
