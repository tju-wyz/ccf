from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from rabo_bc.data import episode_directory, load_manifest
from rabo_bc.policy import BCPolicy, split_rabo_action


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="用缓存episode做一次离线推理")
    parser.add_argument("--prepared-root", required=True, type=Path)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--episode", default=0, type=int)
    parser.add_argument("--frame", default=0, type=int)
    parser.add_argument("--device", default="auto")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    manifest = load_manifest(args.prepared_root)
    directory = episode_directory(args.prepared_root, args.episode)
    images = np.load(directory / "images.npy", mmap_mode="r")
    states = np.load(directory / "states.npy", mmap_mode="r")
    if args.frame < 0 or args.frame >= len(states):
        raise IndexError(f"frame超界：0 <= frame < {len(states)}")
    camera_images = {
        name: np.transpose(np.asarray(images[args.frame, i]), (1, 2, 0))
        for i, name in enumerate(manifest["camera_names"])
    }
    policy = BCPolicy(args.checkpoint, device=args.device)
    chunk = policy.predict(camera_images, np.asarray(states[args.frame]), images_are_bgr=False)
    print(f"prediction shape={chunk.shape}")
    print("第一个绝对关节目标：")
    print(chunk[0])
    print("拆分结果：")
    for name, values in split_rabo_action(chunk[0]).items():
        print(name, values)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

