﻿"""Rabo fixed-scene hierarchical imitation entry point."""

from agents.rabo_hierarchy_agent import run


if __name__ == "__main__":
    run()
