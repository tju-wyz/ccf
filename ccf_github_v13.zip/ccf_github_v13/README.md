# Rabo Fixed-Scene Hierarchical Imitation Agent

本仓库整理自 Rabo 仿真平台实际运行文件。当前生效版本是 **V13 官方自动运行版 + 左手力保持补丁**，不是 V14。

系统面向固定场景下的双臂螺母搬运任务：右手按 B、C、A 顺序抓取，交给左手后放置。最终执行并非纯端到端神经网络，而是由分层模仿模型、episode01 专家关节轨迹回放、固定关节校准和 SDK 手部原语组成的混合控制系统。

## 文档

- [技术总结](docs/TECHNICAL_SUMMARY_CN.md)
- [部署与使用方法](docs/USAGE_CN.md)
- [版本审计与文件整理](docs/VERSION_AUDIT_CN.md)

## 核心目录

```text
agents/rabo_hierarchy_agent/   分层控制器与运行配置
drivers/                       ROS2 传感器与 Rabo SDK 执行适配
rabo_bc/                       分层模型结构、归一化与推理策略
models/hierarchy_ep01.pt       episode01 固定场景模型
collector/                     数据采集器源码，不含原始数据集
research/baseline_v2/          早期 residual-BC 基线训练与评估资料
tests/                         控制器和手部原语测试
docs/                          技术与使用文档
```

## 快速说明

平台启动入口为：

```bash
python3 -u main.py
```

默认配置为仿真模式、ROS2 传感器、CPU 推理和正式自动运行。正式使用前必须确认平台中的机器人、相机和世界 ID 与 `config.yaml` 一致，并使用固定场景配置。

## 适用范围

当前成果验证的是固定场景、固定初始条件下的单示范分层复现能力。部署过程中不会读取螺母坐标并在线求逆运动学，但仓库保存了场景坐标和离线校准结果以便复现实验。它不代表对随机物体位置的泛化能力。

## 公开前注意

`config.yaml` 包含平台资源 ID，`FIXED_SCENE_EPISODE01.json` 包含比赛场景坐标。公开 GitHub 仓库前，应先确认比赛规则和平台方是否允许公开这些信息；规则未确认时建议使用私有仓库。

