﻿"""Rabo competition agents."""
