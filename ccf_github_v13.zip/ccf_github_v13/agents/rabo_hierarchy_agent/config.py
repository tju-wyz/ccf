"""Fail-closed settings for the fixed episode01 hierarchy."""

from __future__ import annotations

import os
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
CHECKPOINT_PATH = PROJECT_ROOT / "models" / "hierarchy_ep01.pt"
ROBOT_CONFIG_PATH = PROJECT_ROOT / "config.yaml"
REQUEST_PATH = PROJECT_ROOT / "RUN_HIERARCHY_EP01_ONCE"
CLAIM_PATH = PROJECT_ROOT / ".hierarchy_ep01_claimed"
C_CALIBRATION_REQUEST_PATH = PROJECT_ROOT / "CALIBRATE_C_Z_MINUS_008_ONCE"
C_CALIBRATION_CLAIM_PATH = PROJECT_ROOT / ".c_z_minus_008_calibration_claimed"
C_GRASP_OVERRIDE_PATH = PROJECT_ROOT / "C_GRASP_Z_MINUS_008_JOINTS.json"
A_CALIBRATION_REQUEST_PATH = (
    PROJECT_ROOT / "CALIBRATE_A_AFTER_WORLD_Y_MINUS_005_ONCE"
)
A_CALIBRATION_CLAIM_PATH = (
    PROJECT_ROOT / ".a_world_y_minus_005_calibration_claimed"
)
A_GRASP_OVERRIDE_PATH = PROJECT_ROOT / "A_GRASP_WORLD_Y_MINUS_005_JOINTS.json"
A_LIFT_OVERRIDE_PATH = PROJECT_ROOT / "A_LIFT_WORLD_Y_MINUS_005_JOINTS.json"


def _float(name: str, default: float) -> float:
    return float(os.getenv(name, str(default)))


def _int(name: str, default: int) -> int:
    return int(os.getenv(name, str(default)))


ONE_SHOT_TEST = False
if REQUEST_PATH.is_file():
    try:
        os.replace(REQUEST_PATH, CLAIM_PATH)
        ONE_SHOT_TEST = True
    except OSError as exc:
        print(f"[safety] unable to claim hierarchy test: {exc!r}", flush=True)

CALIBRATE_C_Z = False
if ONE_SHOT_TEST and C_CALIBRATION_REQUEST_PATH.is_file():
    try:
        os.replace(C_CALIBRATION_REQUEST_PATH, C_CALIBRATION_CLAIM_PATH)
        CALIBRATE_C_Z = True
    except OSError as exc:
        print(f"[safety] unable to claim C calibration: {exc!r}", flush=True)

CALIBRATE_A_Y = False
if ONE_SHOT_TEST and A_CALIBRATION_REQUEST_PATH.is_file():
    try:
        os.replace(A_CALIBRATION_REQUEST_PATH, A_CALIBRATION_CLAIM_PATH)
        CALIBRATE_A_Y = True
    except OSError as exc:
        print(f"[safety] unable to claim A calibration: {exc!r}", flush=True)

OFFICIAL_AUTORUN = os.getenv("RABO_OFFICIAL_AUTORUN", "1").strip().lower() not in {
    "0",
    "false",
    "no",
    "off",
}

MODE = os.getenv("RABO_MODE", "sim")
DEVICE = os.getenv("RABO_HIERARCHY_DEVICE", "cpu")
SENSOR_BACKEND = os.getenv("RABO_SENSOR_BACKEND", "ros2")
CONTROL_HZ = _float("RABO_CONTROL_HZ", 2.0)
READY_TIMEOUT_S = _float("RABO_READY_TIMEOUT_S", 30.0)
STARTUP_DELAY_S = _float("RABO_STARTUP_DELAY_S", 2.0)
OFFICIAL_ACTUATION_DELAY_S = _float(
    "RABO_OFFICIAL_ACTUATION_DELAY_S", 10.0
)
SHADOW_LOG_INTERVAL_S = _float("RABO_SHADOW_LOG_INTERVAL_S", 5.0)
MAX_IMAGE_AGE_MS = _float("RABO_MAX_IMAGE_AGE_MS", 900.0)
PRIMITIVE_FRESH_WAIT_S = _float("RABO_PRIMITIVE_FRESH_WAIT_S", 5.0)
MAX_INFERENCE_MS = _float("RABO_MAX_INFERENCE_MS", 600.0)
C_GRASP_Z_CALIBRATION_OFFSET_M = -0.08
A_WORLD_Y_OFFSET_M = -0.05
A_GRASP_ARM_Y_CALIBRATION_OFFSET_M = 0.05
A_LIFT_CLEAR_Z_CALIBRATION_OFFSET_M = 0.08
FIXED_GRASP_OVERRIDE_TOLERANCE_RAD = _float(
    "RABO_FIXED_GRASP_OVERRIDE_TOLERANCE_RAD", 0.02
)
C_GRASP_OVERRIDE_TOLERANCE_RAD = FIXED_GRASP_OVERRIDE_TOLERANCE_RAD
MAX_ARM_STEP_RAD = _float("RABO_MAX_ARM_STEP_RAD", 0.04)
MAX_HAND_STEP_RAD = _float("RABO_MAX_HAND_STEP_RAD", 0.08)
LEFT_FORCE_HOLD_STRENGTH = _float("RABO_LEFT_FORCE_HOLD_STRENGTH", 1.0)
LEFT_FORCE_HOLD_REFRESH_CYCLES = _int(
    "RABO_LEFT_FORCE_HOLD_REFRESH_CYCLES", 8
)
COMPLETION_THRESHOLD = _float("RABO_COMPLETION_THRESHOLD", 0.80)
COMPLETION_CONFIRM_FRAMES = _int("RABO_COMPLETION_CONFIRM_FRAMES", 2)
TARGET_BLEND = _float("RABO_TARGET_BLEND", 0.70)
STAGE_CYCLE_MULTIPLIER = _float("RABO_STAGE_CYCLE_MULTIPLIER", 3.0)
MAX_CONSECUTIVE_SKIPS = _int("RABO_MAX_CONSECUTIVE_SKIPS", 5)
WARMUP_INFERENCES = _int("RABO_WARMUP_INFERENCES", 3)
ARM_ENDPOINT_TOLERANCE_RAD = _float(
    "RABO_ARM_ENDPOINT_TOLERANCE_RAD", 0.08
)
HAND_ENDPOINT_TOLERANCE_RAD = _float(
    "RABO_HAND_ENDPOINT_TOLERANCE_RAD", 0.12
)
MIN_STAGE_CYCLES = _int("RABO_MIN_STAGE_CYCLES", 2)
MAX_STAGE_CYCLES = _int("RABO_MAX_STAGE_CYCLES", 180)
MAX_SHADOW_CYCLES = _int("RABO_MAX_SHADOW_CYCLES", 0)

if MODE != "sim":
    raise RuntimeError("This overfit hierarchy is restricted to simulation")
if SENSOR_BACKEND not in {"ros2", "mock"}:
    raise ValueError("RABO_SENSOR_BACKEND must be ros2 or mock")
if ONE_SHOT_TEST and SENSOR_BACKEND != "ros2":
    raise RuntimeError("Actuation requires ros2 sensors")
if (
    CONTROL_HZ <= 0
    or STARTUP_DELAY_S < 0
    or OFFICIAL_ACTUATION_DELAY_S < 0
    or PRIMITIVE_FRESH_WAIT_S <= 0
):
    raise ValueError("Invalid timing configuration")
if not -0.20 <= C_GRASP_Z_CALIBRATION_OFFSET_M < 0.0:
    raise ValueError("Invalid C grasp calibration offset")
if not -0.20 < A_WORLD_Y_OFFSET_M < 0.0:
    raise ValueError("Invalid A world y offset")
if not 0.0 < A_GRASP_ARM_Y_CALIBRATION_OFFSET_M <= 0.20:
    raise ValueError("Invalid A arm y calibration offset")
if not 0.0 < A_LIFT_CLEAR_Z_CALIBRATION_OFFSET_M <= 0.20:
    raise ValueError("Invalid A lift-clear calibration offset")
if not 0.0 < FIXED_GRASP_OVERRIDE_TOLERANCE_RAD <= 0.05:
    raise ValueError("Invalid fixed grasp joint override tolerance")
if not 0.0 < LEFT_FORCE_HOLD_STRENGTH <= 1.0:
    raise ValueError("Invalid left force-hold strength")
if LEFT_FORCE_HOLD_REFRESH_CYCLES < 1:
    raise ValueError("Invalid left force-hold refresh cycle count")
if not 0.5 <= COMPLETION_THRESHOLD < 1.0:
    raise ValueError("Invalid completion threshold")
if not 1 <= COMPLETION_CONFIRM_FRAMES <= 5:
    raise ValueError("Invalid completion confirmation count")
if not 0.0 < TARGET_BLEND <= 1.0:
    raise ValueError("RABO_TARGET_BLEND must be in (0, 1]")
if WARMUP_INFERENCES < 0 or MIN_STAGE_CYCLES < 1:
    raise ValueError("Invalid warmup or minimum stage cycles")
if MAX_STAGE_CYCLES < MIN_STAGE_CYCLES:
    raise ValueError("Maximum stage cycles must exceed the minimum")


