"""Fixed-scene episode01 hierarchy controller with guarded joint playback."""

from __future__ import annotations

import concurrent.futures
import json
import math
import signal
import threading
import time
from typing import Any

import numpy as np

from drivers import MockSensorBackend, RaboDevices, Ros2SensorBackend, load_config
from rabo_bc.hierarchy_policy import HierarchicalBCPolicy

from . import config as runtime


PREPOSITION_STAGES = (
    {
        "right": [-1.57, -1.5, 0.0, -1.57, 0.0, -1.0, 0.0],
        "left": [0.0, -1.57, 0.0, 0.0, 0.0, 0.0, 0.0],
    },
    {
        "right": [0.0, 0.0, 0.0, -2.0, 0.0, 1.0, 0.0],
        "left": [-1.57, -0.7, 0.0, 0.0, 0.0, 0.0, 0.0],
    },
)
PREPOSITION_TOLERANCE_RAD = 0.08
FORCE_GRASP_SPECS = {
    "right_grasp_B": ("right_hand", 0.4, (1, 2, 3, 4)),
    "right_grasp_C": ("right_hand", 0.8, None),
    "right_grasp_A": ("right_hand", 0.5, (1, 2, 3, 4, 5)),
    "handoff_B_left_grasp": ("left_hand", 1.0, None),
    "handoff_C_left_grasp": ("left_hand", 1.0, None),
    "handoff_A_left_grasp": ("left_hand", 1.0, None),
}
RIGHT_GRASP_STAGES = {"right_grasp_B", "right_grasp_C", "right_grasp_A"}
LEFT_GRASP_STAGES = {
    "handoff_B_left_grasp",
    "handoff_C_left_grasp",
    "handoff_A_left_grasp",
}
LEFT_PREFORM_STAGES = {
    "left_fine_approach_B",
    "left_fine_approach_C",
    "left_fine_approach_A",
}
RIGHT_RELEASE_STAGES = {
    "handoff_B_right_release",
    "handoff_C_right_release",
    "handoff_A_right_release",
}
LEFT_RELEASE_STAGES = {"release_B", "release_C", "release_A"}
LEFT_FORCE_HOLD_STAGES = {"place_B", "place_C", "place_A"}
RIGHT_THUMB_OPPOSE_TARGET = (1.34, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
RIGHT_RELEASE_TARGET = (1.224, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
LEFT_PREFORM_TARGET = (0.0, 0.29, 0.54, 0.48, 0.429, 0.48, 0.429, 0.48, 0.429, 0.48, 0.429)
LEFT_OPEN_TARGET = (0.0,) * 11


class HierarchyController:
    def __init__(self) -> None:
        if not runtime.CHECKPOINT_PATH.is_file():
            raise FileNotFoundError(f"Checkpoint not found: {runtime.CHECKPOINT_PATH}")
        if not runtime.ROBOT_CONFIG_PATH.is_file():
            raise FileNotFoundError(f"Robot config not found: {runtime.ROBOT_CONFIG_PATH}")
        if runtime.STARTUP_DELAY_S:
            time.sleep(runtime.STARTUP_DELAY_S)

        self.stop_event = threading.Event()
        self.robot_config = load_config(runtime.ROBOT_CONFIG_PATH)
        self.policy = HierarchicalBCPolicy(
            runtime.CHECKPOINT_PATH, device=runtime.DEVICE
        )
        configured = self.robot_config.raw["dataset"]["cameras"]
        missing = [name for name in self.policy.camera_names if name not in configured]
        if missing:
            raise RuntimeError(f"Robot config is missing checkpoint cameras: {missing}")
        expected = ["cam_high", "cam_left_wrist", "cam_right_wrist"]
        if self.policy.camera_names != expected:
            raise RuntimeError(
                f"Unexpected checkpoint cameras: {self.policy.camera_names}; "
                f"expected {expected}"
            )

        self.robot_config.raw["dataset"]["cameras"] = {
            name: configured[name] for name in self.policy.camera_names
        }
        self.robot_config.raw["dataset"]["primary_camera"] = self.policy.camera_names[0]
        # Freshness is checked before every command. A transient platform camera
        # stall should be reported by this controller rather than by the collector.
        self.robot_config.raw["dataset"]["camera_stall_timeout_s"] = 86400.0
        self.robot_config.validate()

        data = self.policy.data_config
        if not bool(data.get("fixed_scene_overfit", False)):
            raise RuntimeError("Checkpoint is not marked as a fixed-scene model")
        self.stage_sequence = list(data["stage_sequence"])
        self.stage_endpoints = {
            name: np.asarray(values, dtype=np.float32)
            for name, values in data["stage_endpoints"].items()
        }
        self.stage_sample_counts = {
            str(name): int(value)
            for name, value in data["stage_sample_counts"].items()
        }
        self.reference_trajectories = {
            str(name): np.asarray(values, dtype=np.float32)
            for name, values in data.get("reference_trajectories", {}).items()
        }
        for name, trajectory in self.reference_trajectories.items():
            if (
                name not in self.stage_sequence
                or trajectory.ndim != 2
                or trajectory.shape[1] != 26
                or not np.isfinite(trajectory).all()
            ):
                raise RuntimeError(
                    f"Invalid reference trajectory for {name}: {trajectory.shape}"
                )
        if set(self.stage_sequence) != set(self.stage_endpoints):
            raise RuntimeError("Checkpoint hierarchy metadata is inconsistent")

        self.devices: RaboDevices | None = None
        if runtime.SENSOR_BACKEND == "mock":
            self.sensors = MockSensorBackend(self.robot_config)
        else:
            self.devices = RaboDevices(self.robot_config, mode=runtime.MODE)
            self.sensors = Ros2SensorBackend(
                self.robot_config,
                joint_reader=self.devices.read_full_state,
                abort_event=self.stop_event,
            )

        self.c_grasp_joint_override = self._load_joint_override(
            runtime.C_GRASP_OVERRIDE_PATH, "C grasp"
        )
        self.a_grasp_joint_override = self._load_joint_override(
            runtime.A_GRASP_OVERRIDE_PATH, "A grasp"
        )
        self.a_lift_joint_override = self._load_joint_override(
            runtime.A_LIFT_OVERRIDE_PATH, "A lift clear"
        )
        a_override_count = sum(
            value is not None
            for value in (
                self.a_grasp_joint_override,
                self.a_lift_joint_override,
            )
        )
        if a_override_count == 1:
            raise RuntimeError(
                "A shifted-scene override is incomplete; both grasp and "
                "lift-clear joint files are required"
            )
        if (
            runtime.ONE_SHOT_TEST
            and not runtime.CALIBRATE_A_Y
            and a_override_count == 0
        ):
            raise RuntimeError(
                "Shifted A scene requires one calibration run before actuation"
            )
        self.a_override_ready = a_override_count == 2
        self.fixed_overrides_ready = (
            self.c_grasp_joint_override is not None and self.a_override_ready
        )
        self.actuation_enabled = self._should_actuate(
            runtime.ONE_SHOT_TEST,
            runtime.OFFICIAL_AUTORUN,
            self.fixed_overrides_ready,
        )

    @staticmethod
    def _should_actuate(
        one_shot_test: bool,
        official_autorun: bool,
        fixed_overrides_ready: bool,
    ) -> bool:
        return bool(
            one_shot_test or (official_autorun and fixed_overrides_ready)
        )

    @staticmethod
    def _load_joint_override(path: Any, label: str) -> np.ndarray | None:
        if not path.is_file():
            return None
        payload = json.loads(path.read_text(encoding="utf-8"))
        values = np.asarray(payload.get("joint_angles_rad"), dtype=np.float32)
        if values.shape != (7,) or not np.isfinite(values).all():
            raise RuntimeError(
                f"Invalid {label} joint override: {values.shape}"
            )
        return values

    @staticmethod
    def _json(event: str, **values: Any) -> None:
        print(json.dumps({"event": event, **values}, ensure_ascii=True), flush=True)

    def _request_stop(self, signum: int, _frame: Any) -> None:
        print(f"[signal] received={signum}; stopping", flush=True)
        self.stop_event.set()
        self.sensors.wake()

    @staticmethod
    def _image_ages_ms(snapshot: Any) -> dict[str, float]:
        return {
            name: max(0.0, snapshot.sim_time - stamp) * 1000.0
            for name, stamp in snapshot.image_stamps.items()
        }

    def _sample(self, dt: float) -> Any:
        while not self.stop_event.is_set():
            snapshot = self.sensors.sample_next(dt, dt, self.stop_event)
            if snapshot is not None:
                return snapshot
        raise RuntimeError("Hierarchy interrupted")

    def _sample_fresh_for_primitive(
        self, dt: float, stage: str
    ) -> tuple[Any, dict[str, float]]:
        deadline = time.monotonic() + runtime.PRIMITIVE_FRESH_WAIT_S
        attempts = 0
        while not self.stop_event.is_set():
            snapshot = self._sample(dt)
            ages = self._image_ages_ms(snapshot)
            relevant = [ages[name] for name in self.policy.camera_names]
            max_age = max(relevant, default=0.0)
            has_new_frame = any(
                not snapshot.camera_reused.get(name, False)
                for name in self.policy.camera_names
            )
            if max_age <= runtime.MAX_IMAGE_AGE_MS and has_new_frame:
                return snapshot, ages
            attempts += 1
            self._json(
                "waiting_for_fresh_images",
                stage=stage,
                attempt=attempts,
                max_image_age_ms=round(max_age, 3),
                camera_reused={
                    name: bool(snapshot.camera_reused.get(name, False))
                    for name in self.policy.camera_names
                },
            )
            if time.monotonic() >= deadline:
                raise RuntimeError(
                    f"Fresh-image wait timed out before {stage}: "
                    f"{max_age:.1f} ms after "
                    f"{runtime.PRIMITIVE_FRESH_WAIT_S:.1f}s"
                )
        raise RuntimeError("Hierarchy interrupted")

    def _predict(self, snapshot: Any, stage: str) -> tuple[dict[str, Any], float]:
        started = time.perf_counter()
        prediction = self.policy.predict(
            snapshot.images, snapshot.state, stage, images_are_bgr=True
        )
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        action = np.asarray(prediction["action"], dtype=np.float32)
        if action.shape != (26,) or not np.isfinite(action).all():
            raise RuntimeError(f"Stage {stage} produced an invalid action")
        return prediction, elapsed_ms

    def _unsafe_reasons(
        self, snapshot: Any, inference_ms: float
    ) -> tuple[list[str], dict[str, float]]:
        ages = self._image_ages_ms(snapshot)
        relevant = [ages[name] for name in self.policy.camera_names]
        reasons: list[str] = []
        max_age = max(relevant, default=0.0)
        if max_age > runtime.MAX_IMAGE_AGE_MS:
            reasons.append(f"stale_image:{max_age:.1f}ms")
        if inference_ms > runtime.MAX_INFERENCE_MS:
            reasons.append(f"slow_inference:{inference_ms:.1f}ms")
        return reasons, ages

    @staticmethod
    def _scope(active: np.ndarray) -> str:
        groups: list[str] = []
        if bool(np.any(active < 7)):
            groups.append("left_arm")
        if bool(np.any((active >= 7) & (active < 14))):
            groups.append("right_arm")
        if bool(np.any((active >= 14) & (active < 20))):
            groups.append("left_hand")
        if bool(np.any(active >= 20)):
            groups.append("right_hand")
        if not groups:
            raise ValueError("Active joint set does not select a device")
        return "+".join(groups)

    @staticmethod
    def _endpoint_error(
        state: np.ndarray, endpoint: np.ndarray, active: np.ndarray
    ) -> tuple[float, bool]:
        errors = np.abs(state[active] - endpoint[active])
        tolerances = np.where(
            active < 14,
            runtime.ARM_ENDPOINT_TOLERANCE_RAD,
            runtime.HAND_ENDPOINT_TOLERANCE_RAD,
        )
        return float(np.max(errors, initial=0.0)), bool(np.all(errors <= tolerances))

    def _run_shadow(self, dt: float) -> None:
        stage = self.stage_sequence[0]
        self._json(
            "actuation_locked",
            instruction=(
                "upload an empty RUN_HIERARCHY_EP01_ONCE file to the Agent root "
                "and restart"
            ),
        )
        last_log = 0.0
        cycles = 0
        while not self.stop_event.is_set():
            snapshot = self._sample(dt)
            prediction, inference_ms = self._predict(snapshot, stage)
            cycles += 1
            now = time.monotonic()
            if now - last_log >= runtime.SHADOW_LOG_INTERVAL_S:
                reasons, ages = self._unsafe_reasons(snapshot, inference_ms)
                self._json(
                    "shadow_prediction",
                    stage=stage,
                    completion_probability=round(
                        float(prediction["completion_probability"]), 6
                    ),
                    inference_ms=round(inference_ms, 3),
                    unsafe_reasons=reasons,
                    image_age_ms={k: round(v, 3) for k, v in ages.items()},
                    camera_reused={
                        name: bool(snapshot.camera_reused.get(name, False))
                        for name in self.policy.camera_names
                    },
                )
                last_log = now
            if runtime.MAX_SHADOW_CYCLES and cycles >= runtime.MAX_SHADOW_CYCLES:
                return

    def _stage_limits(self, stage: str) -> tuple[int, int]:
        samples = self.stage_sample_counts[stage]
        minimum = max(runtime.MIN_STAGE_CYCLES, min(6, math.ceil(samples * 0.2)))
        maximum = max(
            minimum + 2,
            min(
                runtime.MAX_STAGE_CYCLES,
                math.ceil(samples * runtime.STAGE_CYCLE_MULTIPLIER),
            ),
        )
        return minimum, maximum

    def _move_arm_pair_blocking(
        self, right_target: list[float], left_target: list[float]
    ) -> dict[str, bool]:
        assert self.devices is not None
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            futures = {
                "right_arm": executor.submit(
                    self.devices.right_arm.move_joints,
                    right_target,
                    blocking=True,
                ),
                "left_arm": executor.submit(
                    self.devices.left_arm.move_joints,
                    left_target,
                    blocking=True,
                ),
            }
            return {
                name: bool(future.result(timeout=30.0))
                for name, future in futures.items()
            }

    def _run_fixed_preposition(self, stage_index: int) -> None:
        """Run the two joint waypoints used to create episode01."""
        assert self.devices is not None
        self._json(
            "stage_start",
            stage_index=stage_index,
            stage="pre_position",
            execution_mode="fixed_joint_waypoints",
            waypoints=len(PREPOSITION_STAGES),
        )
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            futures = {
                "left_hand": executor.submit(
                    self.devices.left_hand.move_joints,
                    [0.0] * 11,
                    blocking=True,
                ),
                "right_hand": executor.submit(
                    self.devices.right_hand.move_joints,
                    [0.0] * 11,
                    blocking=True,
                ),
            }
            hand_results = {
                name: bool(future.result(timeout=20.0))
                for name, future in futures.items()
            }
        if not all(hand_results.values()):
            raise RuntimeError(f"Unable to open hands: {hand_results}")

        for waypoint, targets in enumerate(PREPOSITION_STAGES, start=1):
            if self.stop_event.is_set():
                raise RuntimeError("Pre-position interrupted")
            results = self._move_arm_pair_blocking(
                targets["right"], targets["left"]
            )
            self._json(
                "fixed_preposition_waypoint_complete",
                waypoint=waypoint,
                waypoints=len(PREPOSITION_STAGES),
                results=results,
            )
            if not all(results.values()):
                raise RuntimeError(
                    f"Pre-position waypoint {waypoint} rejected: {results}"
                )

        expected = PREPOSITION_STAGES[-1]
        right = np.asarray(
            self.devices.right_arm.get_joint_angles(), dtype=np.float32
        )
        left = np.asarray(
            self.devices.left_arm.get_joint_angles(), dtype=np.float32
        )
        right_error = float(
            np.max(np.abs(right - np.asarray(expected["right"], dtype=np.float32)))
        )
        left_error = float(
            np.max(np.abs(left - np.asarray(expected["left"], dtype=np.float32)))
        )
        self._json(
            "fixed_preposition_verified",
            right_max_error_rad=round(right_error, 6),
            left_max_error_rad=round(left_error, 6),
        )
        if max(right_error, left_error) > PREPOSITION_TOLERANCE_RAD:
            raise RuntimeError(
                f"Fixed pre-position did not converge: right={right_error:.4f}, "
                f"left={left_error:.4f} rad"
            )
        self._json(
            "stage_complete",
            stage_index=stage_index,
            stage="pre_position",
            execution_mode="fixed_joint_waypoints",
            right_max_error_rad=round(right_error, 6),
            left_max_error_rad=round(left_error, 6),
        )
    def _command_hand_primitive(
        self,
        hand_name: str,
        target: tuple[float, ...],
        label: str,
    ) -> float:
        assert self.devices is not None
        hand = getattr(self.devices, hand_name)
        self._json(
            "expert_hand_primitive_start",
            label=label,
            hand=hand_name,
            target=[round(value, 6) for value in target],
        )
        result = bool(hand.move_joints(list(target), blocking=True))
        current = np.asarray(hand.get_joint_angles(), dtype=np.float32)
        if current.shape != (11,) or not np.isfinite(current).all():
            raise RuntimeError(
                f"Invalid hand state after primitive: label={label}, "
                f"shape={current.shape}"
            )
        error = float(
            np.max(np.abs(current - np.asarray(target, dtype=np.float32)))
        )
        release_tolerance_accept = (
            not result
            and label.endswith(":release")
            and error <= runtime.HAND_ENDPOINT_TOLERANCE_RAD
        )
        if not result and not release_tolerance_accept:
            raise RuntimeError(
                f"Expert hand primitive rejected: label={label}, "
                f"hand={hand_name}, max_error_rad={error:.4f}"
            )
        self._json(
            "expert_hand_primitive_complete",
            label=label,
            hand=hand_name,
            sdk_result=result,
            accepted_within_release_tolerance=release_tolerance_accept,
            max_error_rad=round(error, 6),
        )
        return error

    def _run_expert_grasp_stage(
        self, stage: str, stage_index: int, dt: float
    ) -> None:
        snapshot, ages = self._sample_fresh_for_primitive(dt, stage)
        self._json(
            "stage_start",
            stage_index=stage_index,
            stage=stage,
            execution_mode="expert_hand_primitive",
            image_age_ms={k: round(v, 3) for k, v in ages.items()},
        )
        if stage in RIGHT_GRASP_STAGES:
            thumb_error = self._command_hand_primitive(
                "right_hand",
                RIGHT_THUMB_OPPOSE_TARGET,
                f"{stage}:thumb_oppose",
            )
            if thumb_error > runtime.HAND_ENDPOINT_TOLERANCE_RAD:
                raise RuntimeError(
                    f"Right thumb did not reach opposition before {stage}: "
                    f"{thumb_error:.4f} rad"
                )
        force_grasp = self._apply_force_grasp(stage)
        if force_grasp is None:
            raise RuntimeError(f"Missing force grasp specification: {stage}")
        self._json(
            "stage_complete",
            stage_index=stage_index,
            stage=stage,
            execution_mode="expert_hand_primitive",
            force_grasp=force_grasp,
        )

    def _run_expert_hand_target_stage(
        self,
        stage: str,
        stage_index: int,
        dt: float,
        hand_name: str,
        target: tuple[float, ...],
        label: str,
    ) -> None:
        snapshot, ages = self._sample_fresh_for_primitive(dt, stage)
        self._json(
            "stage_start",
            stage_index=stage_index,
            stage=stage,
            execution_mode="expert_hand_primitive",
            image_age_ms={k: round(v, 3) for k, v in ages.items()},
        )
        error = self._command_hand_primitive(hand_name, target, label)
        self._json(
            "stage_complete",
            stage_index=stage_index,
            stage=stage,
            execution_mode="expert_hand_primitive",
            max_error_rad=round(error, 6),
        )

    def _apply_force_grasp(self, stage: str) -> dict[str, object] | None:
        spec = FORCE_GRASP_SPECS.get(stage)
        if spec is None:
            return None
        assert self.devices is not None
        hand_name, strength, fingers = spec
        hand = getattr(self.devices, hand_name)
        grasp_force = getattr(hand, "grasp_force", None)
        if not callable(grasp_force):
            raise RuntimeError(
                f"{hand_name} does not expose grasp_force in this runtime"
            )
        finger_list = None if fingers is None else list(fingers)
        before = np.asarray(hand.get_joint_angles(), dtype=np.float32)
        self._json(
            "expert_force_grasp_start",
            stage=stage,
            hand=hand_name,
            strength=strength,
            fingers=finger_list,
        )
        result = bool(
            grasp_force(
                strength=strength,
                fingers=finger_list,
                blocking=True,
            )
        )
        if not result:
            raise RuntimeError(
                f"Expert force grasp rejected: stage={stage}, hand={hand_name}"
            )
        after = np.asarray(hand.get_joint_angles(), dtype=np.float32)
        joint_delta: list[float] | None = None
        non_thumb_max_delta: float | None = None
        non_thumb_moved_joints: int | None = None
        if (
            before.shape == (11,)
            and after.shape == (11,)
            and np.isfinite(before).all()
            and np.isfinite(after).all()
        ):
            delta = np.abs(after - before)
            joint_delta = [round(float(value), 6) for value in delta]
            if stage == "right_grasp_C":
                non_thumb = delta[3:11]
                non_thumb_max_delta = float(np.max(non_thumb, initial=0.0))
                non_thumb_moved_joints = int(np.count_nonzero(non_thumb >= 0.01))
        forces: list[float] | None = None
        try:
            values = np.asarray(hand.get_joint_forces(), dtype=np.float32)
            if values.shape == (11,) and np.isfinite(values).all():
                forces = [round(float(value), 6) for value in values]
        except Exception as exc:
            self._json(
                "force_diagnostic_warning",
                stage=stage,
                hand=hand_name,
                error=repr(exc),
            )
        details = {
            "hand": hand_name,
            "strength": strength,
            "fingers": finger_list,
            "joint_forces_nm": forces,
            "joint_delta_rad": joint_delta,
            "non_thumb_max_delta_rad": (
                None
                if non_thumb_max_delta is None
                else round(non_thumb_max_delta, 6)
            ),
            "non_thumb_moved_joints": non_thumb_moved_joints,
        }
        self._json("expert_force_grasp_complete", stage=stage, **details)
        return details

    def _refresh_left_force_hold(self, stage: str, cycle: int) -> None:
        assert self.devices is not None
        result = bool(
            self.devices.left_hand.grasp_force(
                strength=runtime.LEFT_FORCE_HOLD_STRENGTH,
                fingers=None,
                blocking=False,
            )
        )
        if not result:
            raise RuntimeError(
                f"Left force-hold refresh rejected: stage={stage}, cycle={cycle}"
            )
        self._json(
            "left_force_hold_refreshed",
            stage=stage,
            cycle=cycle,
            strength=runtime.LEFT_FORCE_HOLD_STRENGTH,
            blocking=False,
        )

    def _run_reference_stage(
        self,
        stage: str,
        stage_index: int,
        active: np.ndarray,
        dt: float,
        preform_after_waypoint: int | None = None,
        start_waypoint: int = 0,
    ) -> None:
        """Replay a recorded joint path with feedback and SDK slew limiting."""
        assert self.devices is not None
        reference = self.reference_trajectories[stage]
        if preform_after_waypoint is not None and not (
            0 <= preform_after_waypoint < reference.shape[0] - 1
        ):
            raise ValueError(
                f"Invalid preform waypoint for {stage}: "
                f"{preform_after_waypoint}/{reference.shape[0]}"
            )
        if not 0 <= start_waypoint < reference.shape[0]:
            raise ValueError(
                f"Invalid start waypoint for {stage}: "
                f"{start_waypoint}/{reference.shape[0]}"
            )
        consecutive_skips = 0
        waypoint = start_waypoint
        preform_done = preform_after_waypoint is None
        self._json(
            "stage_start",
            stage_index=stage_index,
            stage=stage,
            execution_mode="episode01_reference_replay",
            reference_waypoints=int(reference.shape[0]),
            reference_start_waypoint=start_waypoint + 1,
            max_cycles=runtime.MAX_STAGE_CYCLES,
            active_indices=active.tolist(),
        )

        for cycle in range(1, runtime.MAX_STAGE_CYCLES + 1):
            snapshot = self._sample(dt)
            prediction, inference_ms = self._predict(snapshot, stage)
            reasons, ages = self._unsafe_reasons(snapshot, inference_ms)
            if reasons:
                consecutive_skips += 1
                self._json(
                    "stage_skipped",
                    stage=stage,
                    cycle=cycle,
                    execution_mode="episode01_reference_replay",
                    reasons=reasons,
                    consecutive_skips=consecutive_skips,
                    image_age_ms={k: round(v, 3) for k, v in ages.items()},
                )
                if consecutive_skips >= runtime.MAX_CONSECUTIVE_SKIPS:
                    raise RuntimeError(
                        f"{stage}: {consecutive_skips} consecutive unsafe cycles"
                    )
                continue
            consecutive_skips = 0

            if stage in LEFT_FORCE_HOLD_STAGES and (
                cycle == 1
                or (cycle - 1) % runtime.LEFT_FORCE_HOLD_REFRESH_CYCLES == 0
            ):
                self._refresh_left_force_hold(stage, cycle)

            if (
                not preform_done
                and preform_after_waypoint is not None
                and waypoint > preform_after_waypoint
            ):
                self._command_hand_primitive(
                    "left_hand", LEFT_PREFORM_TARGET, f"{stage}:preform"
                )
                preform_done = True
                self._json(
                    "left_preform_inserted",
                    stage=stage,
                    after_reference_waypoint=preform_after_waypoint + 1,
                    before_reference_waypoint=waypoint + 1,
                )

            state = np.asarray(snapshot.state, dtype=np.float32)
            desired = state.copy()
            desired[active] = reference[waypoint, active]
            errors = np.abs(desired[active] - state[active])
            tolerances = np.where(
                active < 14,
                runtime.MAX_ARM_STEP_RAD,
                runtime.MAX_HAND_STEP_RAD,
            )
            waypoint_ready = bool(np.all(errors <= tolerances))

            dispatch_started = time.perf_counter()
            results = self.devices.command_action(
                action=desired,
                current_full_state=snapshot.full_state,
                scope=self._scope(active),
                max_arm_step=runtime.MAX_ARM_STEP_RAD,
                max_hand_step=runtime.MAX_HAND_STEP_RAD,
            )
            dispatch_ms = (time.perf_counter() - dispatch_started) * 1000.0
            if waypoint_ready:
                waypoint += 1

            endpoint_error, _ = self._endpoint_error(
                state, reference[-1], active
            )
            self._json(
                "stage_cycle",
                stage=stage,
                cycle=cycle,
                execution_mode="episode01_reference_replay",
                reference_waypoint=min(waypoint + 1, int(reference.shape[0])),
                reference_waypoints=int(reference.shape[0]),
                completion_probability=round(
                    float(prediction["completion_probability"]), 6
                ),
                endpoint_max_error_rad=round(endpoint_error, 6),
                max_active_target_delta_rad=round(
                    float(np.max(errors, initial=0.0)), 6
                ),
                inference_ms=round(inference_ms, 3),
                dispatch_ms=round(dispatch_ms, 3),
                image_age_ms={k: round(v, 3) for k, v in ages.items()},
                camera_reused={
                    name: bool(snapshot.camera_reused.get(name, False))
                    for name in self.policy.camera_names
                },
                results=results,
                diagnostics=dict(self.devices.last_command_diagnostics),
            )
            if waypoint >= reference.shape[0]:
                if not preform_done:
                    raise RuntimeError(
                        f"{stage}: reference ended before left preform"
                    )
                force_grasp = self._apply_force_grasp(stage)
                self._json(
                    "stage_complete",
                    stage_index=stage_index,
                    stage=stage,
                    cycles=cycle,
                    execution_mode="episode01_reference_replay",
                    endpoint_max_error_rad=round(endpoint_error, 6),
                    force_grasp=force_grasp,
                )
                return

        raise RuntimeError(
            f"Reference stage {stage} timed out at waypoint "
            f"{waypoint + 1}/{reference.shape[0]}"
        )
    def _run_pose_offset_calibration(
        self,
        label: str,
        offset_xyz_m: tuple[float, float, float],
        output_path: Any,
        purpose: str,
    ) -> np.ndarray:
        assert self.devices is not None
        pose = self.devices.right_arm.get_pose()
        if (
            not isinstance(pose, tuple)
            or len(pose) != 2
            or len(pose[0]) != 3
            or len(pose[1]) != 3
        ):
            raise RuntimeError(
                f"Invalid right-arm pose for {label} calibration: {pose!r}"
            )
        position = np.asarray(pose[0], dtype=np.float64)
        orientation = np.asarray(pose[1], dtype=np.float64)
        offset = np.asarray(offset_xyz_m, dtype=np.float64)
        if (
            not np.isfinite(position).all()
            or not np.isfinite(orientation).all()
            or offset.shape != (3,)
            or not np.isfinite(offset).all()
        ):
            raise RuntimeError(f"Non-finite pose or offset for {label}")
        target = position + offset
        self._json(
            f"{label}_calibration_start",
            source_pose=[
                *[round(float(value), 6) for value in position],
                *[round(float(value), 6) for value in orientation],
            ],
            target_pose=[
                *[round(float(value), 6) for value in target],
                *[round(float(value), 6) for value in orientation],
            ],
            offset_xyz_m=[round(float(value), 6) for value in offset],
        )
        result = bool(
            self.devices.right_arm.move_to(
                float(target[0]),
                float(target[1]),
                float(target[2]),
                roll=float(orientation[0]),
                pitch=float(orientation[1]),
                yaw=float(orientation[2]),
                blocking=True,
            )
        )
        if not result:
            raise RuntimeError(f"{label} calibration move_to was rejected")
        joints = np.asarray(
            self.devices.right_arm.get_joint_angles(), dtype=np.float32
        )
        if joints.shape != (7,) or not np.isfinite(joints).all():
            raise RuntimeError(
                f"Invalid calibrated {label} joints: {joints.shape}"
            )
        payload = {
            "version": 1,
            "purpose": purpose,
            "deployment_uses_runtime_object_coordinates": False,
            "calibration_offset_xyz_m": [float(value) for value in offset],
            "source_pose": [float(value) for value in position],
            "target_pose": [
                *[float(value) for value in target],
                *[float(value) for value in orientation],
            ],
            "joint_angles_rad": [float(value) for value in joints],
        }
        temporary = output_path.with_suffix(".json.tmp")
        temporary.write_text(
            json.dumps(payload, ensure_ascii=True, indent=2),
            encoding="utf-8",
        )
        temporary.replace(output_path)
        self._json(
            f"{label}_calibration_complete",
            output=str(output_path),
            joint_angles_rad=[
                round(float(value), 8) for value in joints
            ],
        )
        return joints

    def _run_c_z_calibration(self) -> None:
        self.c_grasp_joint_override = self._run_pose_offset_calibration(
            "c_grasp_z",
            (0.0, 0.0, runtime.C_GRASP_Z_CALIBRATION_OFFSET_M),
            runtime.C_GRASP_OVERRIDE_PATH,
            "fixed-scene C grasp joint override",
        )

    def _run_a_y_calibration(self) -> None:
        self.a_grasp_joint_override = self._run_pose_offset_calibration(
            "a_grasp_y",
            (0.0, runtime.A_GRASP_ARM_Y_CALIBRATION_OFFSET_M, 0.0),
            runtime.A_GRASP_OVERRIDE_PATH,
            "fixed-scene A grasp after world y minus 0.05 m",
        )

    def _run_a_lift_calibration(self) -> None:
        self.a_lift_joint_override = self._run_pose_offset_calibration(
            "a_lift_clear_z",
            (0.0, 0.0, runtime.A_LIFT_CLEAR_Z_CALIBRATION_OFFSET_M),
            runtime.A_LIFT_OVERRIDE_PATH,
            "fixed-scene A vertical lift clear after shifted grasp",
        )

    def _run_right_arm_joint_override(
        self,
        label: str,
        target_joints: np.ndarray,
        dt: float,
    ) -> None:
        assert self.devices is not None
        target = np.asarray(target_joints, dtype=np.float32)
        if target.shape != (7,) or not np.isfinite(target).all():
            raise RuntimeError(
                f"Invalid {label} joint override target: {target.shape}"
            )
        consecutive_skips = 0
        for cycle in range(1, 31):
            snapshot = self._sample(dt)
            reasons, ages = self._unsafe_reasons(snapshot, 0.0)
            if reasons:
                consecutive_skips += 1
                self._json(
                    f"{label}_joint_override_wait",
                    cycle=cycle,
                    reasons=reasons,
                    consecutive_skips=consecutive_skips,
                    image_age_ms={k: round(v, 3) for k, v in ages.items()},
                )
                if consecutive_skips >= runtime.MAX_CONSECUTIVE_SKIPS:
                    raise RuntimeError(
                        f"{label} joint override could not obtain fresh images"
                    )
                continue
            consecutive_skips = 0
            current = np.asarray(snapshot.state[7:14], dtype=np.float32)
            error = float(np.max(np.abs(target - current)))
            if error <= runtime.FIXED_GRASP_OVERRIDE_TOLERANCE_RAD:
                self._json(
                    f"{label}_joint_override_complete",
                    cycles=cycle - 1,
                    max_error_rad=round(error, 6),
                )
                return
            action = np.asarray(snapshot.state, dtype=np.float32).copy()
            action[7:14] = target
            started = time.perf_counter()
            results = self.devices.command_action(
                action=action,
                current_full_state=snapshot.full_state,
                scope="right_arm",
                max_arm_step=runtime.MAX_ARM_STEP_RAD,
                max_hand_step=runtime.MAX_HAND_STEP_RAD,
            )
            self._json(
                f"{label}_joint_override_cycle",
                cycle=cycle,
                max_error_rad=round(error, 6),
                dispatch_ms=round(
                    (time.perf_counter() - started) * 1000.0, 3
                ),
                results=results,
                image_age_ms={k: round(v, 3) for k, v in ages.items()},
            )
        raise RuntimeError(
            f"{label} joint override did not converge in 30 cycles"
        )

    def _run_c_joint_override(self, dt: float) -> None:
        assert self.c_grasp_joint_override is not None
        self._run_right_arm_joint_override(
            "c_grasp", self.c_grasp_joint_override, dt
        )

    def _run_a_grasp_joint_override(self, dt: float) -> None:
        assert self.a_grasp_joint_override is not None
        self._run_right_arm_joint_override(
            "a_grasp", self.a_grasp_joint_override, dt
        )

    def _run_a_lift_joint_override(self, dt: float) -> None:
        assert self.a_lift_joint_override is not None
        self._run_right_arm_joint_override(
            "a_lift_clear", self.a_lift_joint_override, dt
        )

    def _nearest_right_arm_reference_waypoint(
        self, stage: str, target_joints: np.ndarray
    ) -> int:
        reference = self.reference_trajectories[stage]
        errors = np.max(
            np.abs(
                reference[:, 7:14]
                - np.asarray(target_joints, dtype=np.float32)[None, :]
            ),
            axis=1,
        )
        waypoint = int(np.argmin(errors))
        self._json(
            "reference_resume_selected",
            stage=stage,
            reference_waypoint=waypoint + 1,
            reference_waypoints=int(reference.shape[0]),
            right_arm_max_error_rad=round(float(errors[waypoint]), 6),
        )
        return waypoint
    def _run_stage(self, stage: str, stage_index: int, dt: float) -> None:
        assert self.devices is not None
        if stage == "pre_position":
            self._run_fixed_preposition(stage_index)
            return
        if stage in RIGHT_GRASP_STAGES or stage in LEFT_GRASP_STAGES:
            self._run_expert_grasp_stage(stage, stage_index, dt)
            return
        if stage in RIGHT_RELEASE_STAGES:
            self._run_expert_hand_target_stage(
                stage,
                stage_index,
                dt,
                "right_hand",
                RIGHT_RELEASE_TARGET,
                f"{stage}:release",
            )
            return

        stage_row = self.policy.stages[self.policy.stage_to_id[stage]]
        active = np.asarray(stage_row["active_indices"], dtype=np.int64)
        if stage in LEFT_PREFORM_STAGES:
            reference = self.reference_trajectories[stage]
            hand_activity = np.max(np.abs(reference[:, 14:20]), axis=1)
            candidates = np.flatnonzero(hand_activity > 0.01)
            if candidates.size == 0:
                raise RuntimeError(
                    f"No expert preform transition recorded for {stage}"
                )
            arm_active = np.arange(0, 7, dtype=np.int64)
            self._run_reference_stage(
                stage,
                stage_index,
                arm_active,
                dt,
                preform_after_waypoint=int(candidates[0]),
            )
            return
        if stage in LEFT_RELEASE_STAGES:
            self._command_hand_primitive(
                "left_hand", LEFT_OPEN_TARGET, f"{stage}:release"
            )
            arm_active = np.arange(0, 7, dtype=np.int64)
            self._run_reference_stage(stage, stage_index, arm_active, dt)
            return

        snapshot = self._sample(dt)
        for _ in range(runtime.WARMUP_INFERENCES if stage_index == 0 else 0):
            self._predict(snapshot, stage)

        if stage in self.reference_trajectories:
            if stage == "lift_and_left_approach_A":
                if runtime.CALIBRATE_A_Y:
                    self._run_a_lift_calibration()
                elif self.a_lift_joint_override is not None:
                    self._run_a_lift_joint_override(dt)
                if self.a_lift_joint_override is None:
                    raise RuntimeError(
                        "A lift-clear joint override is unavailable"
                    )
                resume_waypoint = (
                    self._nearest_right_arm_reference_waypoint(
                        stage, self.a_lift_joint_override
                    )
                )
                self._run_reference_stage(
                    stage,
                    stage_index,
                    active,
                    dt,
                    start_waypoint=resume_waypoint,
                )
                return

            self._run_reference_stage(stage, stage_index, active, dt)
            if stage == "approach_C":
                if runtime.CALIBRATE_C_Z:
                    self._run_c_z_calibration()
                elif self.c_grasp_joint_override is not None:
                    self._run_c_joint_override(dt)
            elif stage == "approach_A":
                if runtime.CALIBRATE_A_Y:
                    self._run_a_y_calibration()
                elif self.a_grasp_joint_override is not None:
                    self._run_a_grasp_joint_override(dt)
            return
        endpoint = self.stage_endpoints[stage]
        minimum, maximum = self._stage_limits(stage)
        previous = np.asarray(snapshot.state, dtype=np.float32).copy()
        confirmed = 0
        consecutive_skips = 0
        self._json(
            "stage_start",
            stage_index=stage_index,
            stage=stage,
            min_cycles=minimum,
            max_cycles=maximum,
            active_indices=active.tolist(),
        )

        for cycle in range(1, maximum + 1):
            snapshot = self._sample(dt)
            prediction, inference_ms = self._predict(snapshot, stage)
            reasons, ages = self._unsafe_reasons(snapshot, inference_ms)
            if reasons:
                consecutive_skips += 1
                self._json(
                    "stage_skipped",
                    stage=stage,
                    cycle=cycle,
                    reasons=reasons,
                    consecutive_skips=consecutive_skips,
                    image_age_ms={k: round(v, 3) for k, v in ages.items()},
                )
                if consecutive_skips >= runtime.MAX_CONSECUTIVE_SKIPS:
                    raise RuntimeError(
                        f"{stage}: {consecutive_skips} consecutive unsafe cycles"
                    )
                continue
            consecutive_skips = 0

            predicted = np.asarray(prediction["action"], dtype=np.float32)
            target = np.asarray(snapshot.state, dtype=np.float32).copy()
            target[active] = (
                runtime.TARGET_BLEND * predicted[active]
                + (1.0 - runtime.TARGET_BLEND) * previous[active]
            )
            dispatch_started = time.perf_counter()
            results = self.devices.command_action(
                action=target,
                current_full_state=snapshot.full_state,
                scope=self._scope(active),
                max_arm_step=runtime.MAX_ARM_STEP_RAD,
                max_hand_step=runtime.MAX_HAND_STEP_RAD,
            )
            dispatch_ms = (time.perf_counter() - dispatch_started) * 1000.0
            previous[active] = target[active]

            probability = float(prediction["completion_probability"])
            endpoint_error, endpoint_ready = self._endpoint_error(
                np.asarray(snapshot.state, dtype=np.float32), endpoint, active
            )
            has_new_frame = any(
                not snapshot.camera_reused.get(name, False)
                for name in self.policy.camera_names
            )
            ready = (
                cycle >= minimum
                and probability >= runtime.COMPLETION_THRESHOLD
                and endpoint_ready
                and has_new_frame
            )
            confirmed = confirmed + 1 if ready else 0
            self._json(
                "stage_cycle",
                stage=stage,
                cycle=cycle,
                completion_probability=round(probability, 6),
                completion_confirmed_frames=confirmed,
                endpoint_max_error_rad=round(endpoint_error, 6),
                max_active_target_delta_rad=round(
                    float(np.max(np.abs(target[active] - snapshot.state[active]))), 6
                ),
                inference_ms=round(inference_ms, 3),
                dispatch_ms=round(dispatch_ms, 3),
                image_age_ms={k: round(v, 3) for k, v in ages.items()},
                camera_reused={
                    name: bool(snapshot.camera_reused.get(name, False))
                    for name in self.policy.camera_names
                },
                results=results,
                diagnostics=dict(self.devices.last_command_diagnostics),
            )
            if confirmed >= runtime.COMPLETION_CONFIRM_FRAMES:
                self._json(
                    "stage_complete",
                    stage_index=stage_index,
                    stage=stage,
                    cycles=cycle,
                    completion_probability=round(probability, 6),
                    endpoint_max_error_rad=round(endpoint_error, 6),
                )
                return

        raise RuntimeError(
            f"Stage {stage} timed out after {maximum} cycles without convergence"
        )

    def _run_hierarchy(self, dt: float) -> None:
        for index, stage in enumerate(self.stage_sequence):
            if self.stop_event.is_set():
                raise RuntimeError("Hierarchy interrupted")
            self._run_stage(stage, index, dt)
        self._json(
            "hierarchy_complete",
            stages=len(self.stage_sequence),
            result="visual_and_task-score verification required",
        )

    def _wait_after_official_run(self, result: str) -> None:
        action_servers_released = False
        if self.devices is not None:
            self.devices.stop()
            self.devices.shutdown()
            self.devices = None
            action_servers_released = True
        self._json(
            "official_run_idle",
            result=result,
            action_servers_released=action_servers_released,
            instruction="stop and restart the simulation for the next episode",
        )
        while not self.stop_event.wait(1.0):
            pass

    def _wait_before_actuation(self) -> None:
        delay = runtime.OFFICIAL_ACTUATION_DELAY_S
        if not delay:
            return
        self._json("official_actuation_delay", seconds=delay)
        if self.stop_event.wait(delay):
            raise RuntimeError("Hierarchy interrupted during actuation delay")

    def run(self) -> None:
        self._json(
            "startup",
            mode=runtime.MODE,
            device=runtime.DEVICE,
            sensor_backend=runtime.SENSOR_BACKEND,
            one_shot_test=runtime.ONE_SHOT_TEST,
            official_autorun=runtime.OFFICIAL_AUTORUN,
            actuation_enabled=self.actuation_enabled,
            checkpoint=str(runtime.CHECKPOINT_PATH),
            source_episode=int(self.policy.data_config["source_episode"]),
            fixed_scene_overfit=bool(self.policy.data_config["fixed_scene_overfit"]),
            camera_names=self.policy.camera_names,
            stages=len(self.stage_sequence),
            calibrate_c_z=runtime.CALIBRATE_C_Z,
            c_grasp_joint_override_loaded=(
                self.c_grasp_joint_override is not None
            ),
            calibrate_a_y=runtime.CALIBRATE_A_Y,
            a_grasp_joint_override_loaded=(
                self.a_grasp_joint_override is not None
            ),
            a_lift_joint_override_loaded=(
                self.a_lift_joint_override is not None
            ),
        )
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, self._request_stop)
            except (ValueError, OSError):
                pass

        dt = 1.0 / runtime.CONTROL_HZ
        try:
            self.sensors.start()
            self.sensors.wait_ready(runtime.READY_TIMEOUT_S)
            self.sensors.reset_clock()
            self._json("sensors_ready")
            if self.actuation_enabled:
                try:
                    self._wait_before_actuation()
                    self._run_hierarchy(dt)
                except Exception as exc:
                    if not runtime.OFFICIAL_AUTORUN:
                        raise
                    self._json("official_run_failed", error=repr(exc))
                    if self.devices is not None:
                        self.devices.stop()
                    self._wait_after_official_run("failed")
                else:
                    if runtime.OFFICIAL_AUTORUN:
                        self._wait_after_official_run("complete")
            else:
                self._run_shadow(dt)
        finally:
            self.stop_event.set()
            self.sensors.close()
            if self.devices is not None:
                if self.actuation_enabled:
                    self.devices.stop()
                self.devices.shutdown()
            self._json("stopped")












