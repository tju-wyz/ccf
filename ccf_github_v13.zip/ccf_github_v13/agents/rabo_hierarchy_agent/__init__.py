﻿"""Fixed-scene hierarchical imitation Agent."""

from .controller import HierarchyController


def run() -> None:
    HierarchyController().run()


__all__ = ["HierarchyController", "run"]
