﻿from __future__ import annotations

import os
from pathlib import Path

import cv2
import numpy as np
import torch

from .hierarchy_model import HierarchicalBCModel
from .normalization import denormalize_numpy, normalize_numpy


class HierarchicalBCPolicy:
    def __init__(self, checkpoint: str | Path, device: str = "auto") -> None:
        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = torch.device(device)
        if self.device.type == "cpu":
            torch.set_num_threads(
                max(1, int(os.getenv("RABO_TORCH_THREADS", "2")))
            )
            try:
                torch.set_num_interop_threads(1)
            except RuntimeError:
                pass
        self.payload = torch.load(
            checkpoint, map_location=self.device, weights_only=False
        )
        self.model = HierarchicalBCModel(
            **self.payload["model_config"]
        ).to(self.device)
        self.model.load_state_dict(self.payload["model"])
        self.model.eval()
        self.stats = self.payload["normalization"]
        self.data_config = self.payload["data_config"]
        self.camera_names = list(self.data_config["camera_names"])
        self.stages = list(self.data_config["stages"])
        self.stage_to_id = {
            row["name"]: int(row["id"]) for row in self.stages
        }
        self.minimum = np.asarray(self.stats["min"], dtype=np.float32)
        self.maximum = np.asarray(self.stats["max"], dtype=np.float32)

    def _prepare_image(
        self, image: np.ndarray, images_are_bgr: bool
    ) -> np.ndarray:
        if image is None or image.ndim != 3 or image.shape[2] != 3:
            raise ValueError(
                f"Expected HxWx3 image, got "
                f"{None if image is None else image.shape}"
            )
        size = (
            int(self.data_config["image_width"]),
            int(self.data_config["image_height"]),
        )
        image = cv2.resize(image, size, interpolation=cv2.INTER_AREA)
        if images_are_bgr:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image = (
            np.transpose(image, (2, 0, 1)).astype(np.float32) / 255.0
        )
        return (image - 0.5) / 0.5

    @torch.inference_mode()
    def predict(
        self,
        images: dict[str, np.ndarray],
        state: np.ndarray,
        stage: str,
        images_are_bgr: bool = True,
    ) -> dict[str, object]:
        if stage not in self.stage_to_id:
            raise ValueError(f"Unknown hierarchy stage: {stage}")
        missing = [name for name in self.camera_names if name not in images]
        if missing:
            raise KeyError(f"Missing cameras: {missing}")
        state = np.asarray(state, dtype=np.float32)
        if state.shape != (26,) or not np.isfinite(state).all():
            raise ValueError(f"Invalid state: {state.shape}")
        image_array = np.stack([
            self._prepare_image(images[name], images_are_bgr)
            for name in self.camera_names
        ])
        image_tensor = torch.from_numpy(image_array).unsqueeze(0).to(
            self.device
        )
        state_tensor = torch.from_numpy(
            normalize_numpy(state, self.stats)
        ).unsqueeze(0).to(self.device)
        stage_id = self.stage_to_id[stage]
        stage_tensor = torch.tensor(
            [stage_id], dtype=torch.int64, device=self.device
        )
        target, completion_logit = self.model(
            image_tensor, state_tensor, stage_tensor
        )
        target_rad = denormalize_numpy(
            target[0].cpu().numpy(), self.stats
        ).astype(np.float32)
        target_rad = np.clip(
            target_rad, self.minimum, self.maximum
        ).astype(np.float32)
        active = np.asarray(
            self.stages[stage_id]["active_indices"], dtype=np.int64
        )
        action = state.copy()
        action[active] = target_rad[active]
        return {
            "action": action,
            "active_indices": active,
            "completion_probability": float(
                torch.sigmoid(completion_logit[0]).cpu()
            ),
            "stage_id": stage_id,
        }
