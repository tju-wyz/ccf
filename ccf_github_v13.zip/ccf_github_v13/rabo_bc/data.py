from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import numpy as np
import torch
from torch.utils.data import Dataset

from .normalization import normalize_numpy


def load_manifest(prepared_root: str | Path) -> dict:
    path = Path(prepared_root) / "manifest.json"
    if not path.exists():
        raise FileNotFoundError(f"找不到预处理清单：{path}")
    return json.loads(path.read_text(encoding="utf-8"))


def episode_directory(prepared_root: Path, episode_index: int) -> Path:
    return prepared_root / f"episode_{episode_index:06d}"


def load_episode_states(prepared_root: str | Path, episode_index: int) -> np.ndarray:
    path = episode_directory(Path(prepared_root), episode_index) / "states.npy"
    return np.load(path, mmap_mode="r")


def split_episode_indices(
    episode_indices: Iterable[int], val_fraction: float = 0.2, seed: int = 42
) -> tuple[list[int], list[int]]:
    values = np.asarray(sorted(set(int(x) for x in episode_indices)), dtype=np.int64)
    if len(values) < 2:
        return values.tolist(), values.tolist()
    rng = np.random.default_rng(seed)
    rng.shuffle(values)
    val_count = max(1, int(round(len(values) * val_fraction)))
    val_count = min(val_count, len(values) - 1)
    return sorted(values[val_count:].tolist()), sorted(values[:val_count].tolist())


class PreparedActionChunkDataset(Dataset):
    """预处理后的内存映射数据；不会把全部视频一次性载入内存。"""

    def __init__(
        self,
        prepared_root: str | Path,
        episode_indices: Iterable[int],
        chunk_size: int,
        stats: dict,
        augment: bool = False,
    ) -> None:
        self.root = Path(prepared_root)
        self.manifest = load_manifest(self.root)
        self.episode_indices = sorted(set(int(x) for x in episode_indices))
        self.chunk_size = int(chunk_size)
        self.stats = stats
        self.augment = bool(augment)
        self.samples: list[tuple[int, int]] = []
        self._cache: dict[int, tuple[np.ndarray, np.ndarray]] = {}

        lengths = {
            int(row["episode_index"]): int(row["prepared_frames"])
            for row in self.manifest["episodes"]
        }
        for episode_index in self.episode_indices:
            if episode_index not in lengths:
                raise KeyError(f"manifest中没有episode {episode_index}")
            usable = lengths[episode_index] - self.chunk_size
            if usable <= 0:
                continue
            self.samples.extend((episode_index, position) for position in range(usable))
        if not self.samples:
            raise ValueError("没有可用于动作块训练的样本")

    def __len__(self) -> int:
        return len(self.samples)

    def __getstate__(self):
        state = dict(self.__dict__)
        state["_cache"] = {}
        return state

    def _open_episode(self, episode_index: int) -> tuple[np.ndarray, np.ndarray]:
        if episode_index not in self._cache:
            directory = episode_directory(self.root, episode_index)
            images = np.load(directory / "images.npy", mmap_mode="r")
            states = np.load(directory / "states.npy", mmap_mode="r")
            self._cache[episode_index] = (images, states)
        return self._cache[episode_index]

    def __getitem__(self, item: int) -> dict[str, torch.Tensor]:
        episode_index, position = self.samples[item]
        images, states = self._open_episode(episode_index)

        image = np.array(images[position], dtype=np.float32, copy=True) / 255.0
        if self.augment:
            # 同一组相机使用同一亮度变化，不能做水平翻转（会交换左右语义）。
            gain = float(np.random.uniform(0.90, 1.10))
            bias = float(np.random.uniform(-0.03, 0.03))
            image = np.clip(image * gain + bias, 0.0, 1.0)
        image = (image - 0.5) / 0.5

        state = normalize_numpy(np.asarray(states[position]), self.stats)
        future = np.asarray(
            states[position + 1 : position + 1 + self.chunk_size], dtype=np.float32
        )
        actions = normalize_numpy(future, self.stats)
        return {
            "images": torch.from_numpy(image),
            "state": torch.from_numpy(state),
            "actions": torch.from_numpy(actions),
            "episode_index": torch.tensor(episode_index, dtype=torch.int64),
            "frame_index": torch.tensor(position, dtype=torch.int64),
        }

