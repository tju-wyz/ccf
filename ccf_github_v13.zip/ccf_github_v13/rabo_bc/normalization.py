from __future__ import annotations

import numpy as np
import torch


def compute_percentile_stats(arrays: list[np.ndarray]) -> dict[str, list[float]]:
    if not arrays:
        raise ValueError("训练集为空，无法计算归一化统计量")
    values = np.concatenate([np.asarray(x, dtype=np.float32) for x in arrays], axis=0)
    if values.ndim != 2:
        raise ValueError(f"状态必须是二维数组，实际为 {values.shape}")
    return {
        "q01": np.quantile(values, 0.01, axis=0).astype(np.float32).tolist(),
        "q99": np.quantile(values, 0.99, axis=0).astype(np.float32).tolist(),
        "mean": values.mean(axis=0).astype(np.float32).tolist(),
        "std": values.std(axis=0).astype(np.float32).tolist(),
        "min": values.min(axis=0).astype(np.float32).tolist(),
        "max": values.max(axis=0).astype(np.float32).tolist(),
    }


def _numpy_bounds(stats: dict) -> tuple[np.ndarray, np.ndarray]:
    low = np.asarray(stats["q01"], dtype=np.float32)
    high = np.asarray(stats["q99"], dtype=np.float32)
    high = np.where(high - low < 1e-4, low + 1e-4, high)
    return low, high


def normalize_numpy(values: np.ndarray, stats: dict, clip: bool = True) -> np.ndarray:
    low, high = _numpy_bounds(stats)
    values = np.asarray(values, dtype=np.float32)
    normalized = 2.0 * (values - low) / (high - low) - 1.0
    return np.clip(normalized, -1.0, 1.0) if clip else normalized


def denormalize_numpy(values: np.ndarray, stats: dict) -> np.ndarray:
    low, high = _numpy_bounds(stats)
    values = np.asarray(values, dtype=np.float32)
    return (values + 1.0) * 0.5 * (high - low) + low


def denormalize_torch(values: torch.Tensor, stats: dict) -> torch.Tensor:
    low = torch.as_tensor(stats["q01"], dtype=values.dtype, device=values.device)
    high = torch.as_tensor(stats["q99"], dtype=values.dtype, device=values.device)
    high = torch.where(high - low < 1e-4, low + 1e-4, high)
    return (values + 1.0) * 0.5 * (high - low) + low

