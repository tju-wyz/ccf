from __future__ import annotations

import os
from pathlib import Path

import cv2
import numpy as np
import torch

from .model import TinyVisualBC
from .normalization import denormalize_numpy, normalize_numpy


def _load_checkpoint(path: str | Path, device: torch.device) -> dict:
    try:
        return torch.load(path, map_location=device, weights_only=False)
    except TypeError:  # 兼容较老的 PyTorch 2.x
        return torch.load(path, map_location=device)


class BCPolicy:
    """部署侧最小包装：三张BGR/RGB图 + 26维状态 -> [L,26]绝对目标。"""

    def __init__(self, checkpoint: str | Path, device: str = "auto") -> None:
        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = torch.device(device)
        if self.device.type == "cpu":
            torch.set_num_threads(max(1, int(os.getenv("RABO_TORCH_THREADS", "2"))))
            try:
                torch.set_num_interop_threads(1)
            except RuntimeError:
                pass
        payload = _load_checkpoint(checkpoint, self.device)
        self.model = TinyVisualBC(**payload["model_config"]).to(self.device)
        self.model.load_state_dict(payload["model"])
        self.model.eval()
        self.stats = payload["normalization"]
        self.data_config = payload["data_config"]
        self.camera_names = list(self.data_config["camera_names"])

    def _prepare_image(self, image: np.ndarray, images_are_bgr: bool) -> np.ndarray:
        if image is None or image.ndim != 3 or image.shape[2] != 3:
            raise ValueError(f"相机图像必须是H×W×3，实际为{None if image is None else image.shape}")
        width = int(self.data_config["image_width"])
        height = int(self.data_config["image_height"])
        image = cv2.resize(image, (width, height), interpolation=cv2.INTER_AREA)
        if images_are_bgr:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image = np.transpose(image, (2, 0, 1)).astype(np.float32) / 255.0
        return (image - 0.5) / 0.5

    @torch.inference_mode()
    def predict(
        self,
        images: dict[str, np.ndarray],
        state: np.ndarray,
        images_are_bgr: bool = True,
    ) -> np.ndarray:
        missing = [name for name in self.camera_names if name not in images]
        if missing:
            raise KeyError(f"缺少相机：{missing}")
        image_array = np.stack(
            [self._prepare_image(images[name], images_are_bgr) for name in self.camera_names]
        )
        state = np.asarray(state, dtype=np.float32)
        expected = int(self.model.state_dim)
        if state.shape != (expected,):
            raise ValueError(f"state应为[{expected}]，实际为{state.shape}")
        state_norm = normalize_numpy(state, self.stats)
        image_tensor = torch.from_numpy(image_array).unsqueeze(0).to(self.device)
        state_tensor = torch.from_numpy(state_norm).unsqueeze(0).to(self.device)
        prediction = self.model(image_tensor, state_tensor)[0].cpu().numpy()
        actions = denormalize_numpy(prediction, self.stats)
        low = np.asarray(self.stats["min"], dtype=np.float32)
        high = np.asarray(self.stats["max"], dtype=np.float32)
        return np.clip(actions, low, high).astype(np.float32)


def split_rabo_action(action: np.ndarray) -> dict[str, np.ndarray]:
    action = np.asarray(action, dtype=np.float32)
    if action.shape != (26,):
        raise ValueError(f"Rabo动作必须为26维，实际为{action.shape}")
    return {
        "left_arm": action[0:7],
        "right_arm": action[7:14],
        "left_hand": action[14:20],
        "right_hand": action[20:26],
    }
