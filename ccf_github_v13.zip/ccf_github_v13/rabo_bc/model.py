from __future__ import annotations

import torch
from torch import nn


def _group_count(channels: int) -> int:
    for groups in (8, 4, 2, 1):
        if channels % groups == 0:
            return groups
    return 1


class TinyImageEncoder(nn.Module):
    """不依赖预训练权重的小型共享视觉编码器。"""

    def __init__(self, output_dim: int = 128):
        super().__init__()
        layers: list[nn.Module] = []
        in_channels = 3
        for out_channels, kernel in ((24, 5), (48, 3), (96, 3), (128, 3)):
            layers.extend(
                [
                    nn.Conv2d(
                        in_channels,
                        out_channels,
                        kernel_size=kernel,
                        stride=2,
                        padding=kernel // 2,
                        bias=False,
                    ),
                    nn.GroupNorm(_group_count(out_channels), out_channels),
                    nn.SiLU(inplace=True),
                ]
            )
            in_channels = out_channels
        layers.append(nn.AdaptiveAvgPool2d(1))
        self.backbone = nn.Sequential(*layers)
        self.projection = nn.Linear(128, output_dim)

    def forward(self, images: torch.Tensor) -> torch.Tensor:
        features = self.backbone(images).flatten(1)
        return self.projection(features)


class TinyVisualBC(nn.Module):
    """三相机 + 26维状态 -> 未来关节动作块。"""

    def __init__(
        self,
        num_cameras: int = 3,
        state_dim: int = 26,
        action_dim: int = 26,
        chunk_size: int = 8,
        visual_feature_dim: int = 128,
        hidden_dim: int = 256,
        dropout: float = 0.1,
        prediction_mode: str = "absolute",
    ) -> None:
        super().__init__()
        if num_cameras < 1:
            raise ValueError("num_cameras 必须至少为1")
        self.num_cameras = int(num_cameras)
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.chunk_size = int(chunk_size)
        if prediction_mode not in {"absolute", "residual"}:
            raise ValueError("prediction_mode 必须是 absolute 或 residual")
        if prediction_mode == "residual" and self.state_dim != self.action_dim:
            raise ValueError("residual 模式要求 state_dim == action_dim")
        self.prediction_mode = prediction_mode

        self.image_encoder = TinyImageEncoder(visual_feature_dim)
        self.camera_embedding = nn.Parameter(
            torch.zeros(self.num_cameras, visual_feature_dim)
        )
        nn.init.normal_(self.camera_embedding, std=0.02)

        self.state_encoder = nn.Sequential(
            nn.Linear(self.state_dim, 64),
            nn.SiLU(inplace=True),
            nn.Linear(64, 64),
            nn.SiLU(inplace=True),
        )
        fusion_dim = self.num_cameras * visual_feature_dim + 64
        self.fusion = nn.Sequential(
            nn.Linear(fusion_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(inplace=True),
        )
        self.action_head = nn.Linear(hidden_dim, self.chunk_size * self.action_dim)
        if self.prediction_mode == "residual":
            # 初始策略严格等于保持当前关节位置的 persistence baseline。
            nn.init.zeros_(self.action_head.weight)
            nn.init.zeros_(self.action_head.bias)

    def forward(self, images: torch.Tensor, state: torch.Tensor) -> torch.Tensor:
        if images.ndim != 5:
            raise ValueError(f"images应为[B,Cam,3,H,W]，实际为{tuple(images.shape)}")
        batch, cameras, channels, height, width = images.shape
        if cameras != self.num_cameras or channels != 3:
            raise ValueError(
                f"期望{self.num_cameras}路RGB相机，实际shape={tuple(images.shape)}"
            )
        encoded = self.image_encoder(images.reshape(batch * cameras, 3, height, width))
        encoded = encoded.reshape(batch, cameras, -1)
        encoded = encoded + self.camera_embedding.unsqueeze(0)
        visual = encoded.flatten(1)
        state_features = self.state_encoder(state)
        fused = self.fusion(torch.cat([visual, state_features], dim=-1))
        actions = self.action_head(fused).reshape(
            batch, self.chunk_size, self.action_dim
        )
        if self.prediction_mode == "residual":
            actions = state.unsqueeze(1) + actions
        return actions

    def config_dict(self) -> dict[str, int | float | str]:
        return {
            "num_cameras": self.num_cameras,
            "state_dim": self.state_dim,
            "action_dim": self.action_dim,
            "chunk_size": self.chunk_size,
            "visual_feature_dim": self.image_encoder.projection.out_features,
            "hidden_dim": self.fusion[0].out_features,
            "dropout": self.fusion[3].p,
            "prediction_mode": self.prediction_mode,
        }
