﻿from __future__ import annotations

import torch
from torch import nn

from .model import TinyImageEncoder


class HierarchicalBCModel(nn.Module):
    def __init__(
        self,
        num_cameras: int = 3,
        state_dim: int = 26,
        num_stages: int = 28,
        visual_feature_dim: int = 128,
        hidden_dim: int = 256,
        stage_embedding_dim: int = 24,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.num_cameras = int(num_cameras)
        self.state_dim = int(state_dim)
        self.num_stages = int(num_stages)
        self.image_encoder = TinyImageEncoder(visual_feature_dim)
        self.camera_embedding = nn.Parameter(
            torch.zeros(num_cameras, visual_feature_dim)
        )
        nn.init.normal_(self.camera_embedding, std=0.02)
        self.state_encoder = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.SiLU(inplace=True),
            nn.Linear(64, 64),
            nn.SiLU(inplace=True),
        )
        self.stage_embedding = nn.Embedding(
            num_stages, stage_embedding_dim
        )
        fusion_dim = (
            num_cameras * visual_feature_dim + 64 + stage_embedding_dim
        )
        self.fusion = nn.Sequential(
            nn.Linear(fusion_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(inplace=True),
        )
        self.action_heads = nn.ModuleList(
            nn.Linear(hidden_dim, state_dim) for _ in range(num_stages)
        )
        self.completion_heads = nn.ModuleList(
            nn.Linear(hidden_dim, 1) for _ in range(num_stages)
        )
        for head in self.action_heads:
            nn.init.zeros_(head.weight)
            nn.init.zeros_(head.bias)

    def forward(
        self,
        images: torch.Tensor,
        state: torch.Tensor,
        stage_id: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        batch, cameras, channels, _, _ = images.shape
        if cameras != self.num_cameras or channels != 3:
            raise ValueError(
                f"Expected {self.num_cameras} RGB cameras, got {tuple(images.shape)}"
            )
        encoded = self.image_encoder(
            images.reshape(batch * cameras, *images.shape[2:])
        )
        encoded = (
            encoded.reshape(batch, cameras, -1)
            + self.camera_embedding.unsqueeze(0)
        )
        fused = self.fusion(
            torch.cat(
                [
                    encoded.flatten(1),
                    self.state_encoder(state),
                    self.stage_embedding(stage_id),
                ],
                dim=1,
            )
        )
        actions = torch.stack(
            [head(fused) for head in self.action_heads], dim=1
        )
        completions = torch.cat(
            [head(fused) for head in self.completion_heads], dim=1
        )
        gather_action = stage_id.view(-1, 1, 1).expand(
            -1, 1, self.state_dim
        )
        selected_action = actions.gather(1, gather_action).squeeze(1)
        selected_completion = completions.gather(
            1, stage_id.view(-1, 1)
        ).squeeze(1)
        return state + selected_action, selected_completion

    def config_dict(self) -> dict:
        return {
            "num_cameras": self.num_cameras,
            "state_dim": self.state_dim,
            "num_stages": self.num_stages,
            "visual_feature_dim": self.image_encoder.projection.out_features,
            "hidden_dim": self.fusion[0].out_features,
            "stage_embedding_dim": self.stage_embedding.embedding_dim,
            "dropout": self.fusion[3].p,
        }
