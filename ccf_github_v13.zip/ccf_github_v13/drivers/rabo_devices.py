"""Rabo SDK device wrapper with bounded, blocking command dispatch."""

from __future__ import annotations

import concurrent.futures
from collections.abc import Sequence

import numpy as np

from .rabo_config import CollectorConfig

SDK_COMMAND_TIMEOUT_S = 15.0


class RaboDevices:
    """Own four SDK devices and expose the training-time 36D read order."""

    def __init__(self, config: CollectorConfig, mode: str = "sim") -> None:
        try:
            from rabo_robocap import (
                LinkerArmA7,
                LinkerHandO6Left,
                LinkerHandO6Right,
            )
        except ImportError as exc:
            raise RuntimeError("rabo_robocap is required in the Rabo runtime") from exc

        rabo = config.rabo
        self._arm_limits = self._joint_limit_spec(LinkerArmA7, 7)
        self._left_hand_limits, self._left_hand_drive = self._hand_spec(
            LinkerHandO6Left
        )
        self._right_hand_limits, self._right_hand_drive = self._hand_spec(
            LinkerHandO6Right
        )
        self.left_arm = LinkerArmA7(robot_id=rabo["left_arm_id"], mode=mode)
        self.right_arm = LinkerArmA7(robot_id=rabo["right_arm_id"], mode=mode)
        self.left_hand = LinkerHandO6Left(robot_id=rabo["left_hand_id"], mode=mode)
        self.right_hand = LinkerHandO6Right(robot_id=rabo["right_hand_id"], mode=mode)
        self._command_executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=4,
            thread_name_prefix="rabo-command",
        )
        self.last_command_diagnostics: dict[str, object] = {}
        print(f"[sdk-limits] LinkerArmA7={self._arm_limits.tolist()}", flush=True)

    @staticmethod
    def _valid_part(values: object, expected: int) -> bool:
        return isinstance(values, Sequence) and len(values) == expected

    def read_full_state(self) -> np.ndarray | None:
        parts = (
            self.left_arm.get_joint_angles(),
            self.right_arm.get_joint_angles(),
            self.left_hand.get_joint_angles(),
            self.right_hand.get_joint_angles(),
        )
        expected = (7, 7, 11, 11)
        if any(not self._valid_part(part, size) for part, size in zip(parts, expected)):
            return None
        values = np.asarray(
            [float(value) for part in parts for value in part], dtype=np.float32
        )
        if values.shape != (36,) or not np.isfinite(values).all():
            return None
        return values

    @staticmethod
    def _joint_limit_spec(robot_class: object, dof: int) -> np.ndarray:
        limits = np.asarray(
            getattr(robot_class, "JOINT_LIMITS", None), dtype=np.float32
        )
        if limits.shape != (dof, 2) or not np.isfinite(limits).all():
            raise RuntimeError(
                f"Invalid JOINT_LIMITS on {robot_class}: expected {(dof, 2)}, "
                f"got {limits.shape}"
            )
        # Keep commands slightly inside the documented interval. ArmClient
        # performs strict float comparisons and can reject a rounded value
        # printed exactly at the boundary.
        margin = np.float32(0.002)
        limits = limits.copy()
        limits[:, 0] += margin
        limits[:, 1] -= margin
        if np.any(limits[:, 0] >= limits[:, 1]):
            raise RuntimeError(f"Joint-limit margin collapsed range on {robot_class}")
        return limits

    @staticmethod
    def _hand_spec(hand_class: object) -> tuple[np.ndarray, np.ndarray]:
        limits = np.asarray(
            getattr(hand_class, "JOINT_LIMITS", None), dtype=np.float32
        )
        drive = np.asarray(
            getattr(hand_class, "CLENCH_DRIVE", None), dtype=np.int64
        )
        expected_drive = np.asarray(
            (0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5), dtype=np.int64
        )
        if limits.shape != (11, 2) or not np.isfinite(limits).all():
            raise RuntimeError(
                f"Invalid hand JOINT_LIMITS on {hand_class}: {limits.shape}"
            )
        if drive.shape != (11,) or not np.array_equal(drive, expected_drive):
            raise RuntimeError(f"Unexpected hand CLENCH_DRIVE on {hand_class}: {drive}")
        # The SDK compares Python floats against decimal limits strictly.
        # A float32 value such as 1.08000004 is greater than the documented
        # 1.08 maximum, so keep generated hand targets just inside the upper
        # limits. Zero is retained because opening commands legitimately use it.
        limits = limits.copy()
        limits[:, 1] -= np.float32(0.002)
        if np.any(limits[:, 0] >= limits[:, 1]):
            raise RuntimeError(f"Hand joint-limit margin collapsed {hand_class}")
        return limits, drive

    @staticmethod
    def _slew_and_clip(
        desired: np.ndarray,
        current: np.ndarray,
        limits: np.ndarray,
        max_step: float,
    ) -> np.ndarray:
        target = current + np.clip(desired - current, -max_step, max_step)
        return np.clip(target, limits[:, 0], limits[:, 1]).astype(np.float32)

    @staticmethod
    def _slew(
        desired: np.ndarray,
        current: np.ndarray,
        max_step: float,
    ) -> np.ndarray:
        """Limit one command step when the SDK validates its own joint limits."""
        return (
            current + np.clip(desired - current, -max_step, max_step)
        ).astype(np.float32)

    @staticmethod
    def _expand_hand_target(
        active_target: np.ndarray,
        current_full: np.ndarray,
        limits: np.ndarray,
        drive: np.ndarray,
        max_step: float,
    ) -> np.ndarray:
        active_indices = np.asarray((0, 1, 3, 5, 7, 9), dtype=np.int64)

        active_limits = limits[active_indices]
        active_target = np.clip(
            active_target, active_limits[:, 0], active_limits[:, 1]
        )
        span = active_limits[:, 1] - active_limits[:, 0]
        fraction = np.divide(
            active_target - active_limits[:, 0],
            span,
            out=np.zeros_like(active_target),
            where=span > 0,
        )
        full_target = limits[:, 0] + fraction[drive] * (
            limits[:, 1] - limits[:, 0]
        )
        full_target = current_full + np.clip(
            full_target - current_full, -max_step, max_step
        )
        return np.clip(full_target, limits[:, 0], limits[:, 1]).astype(np.float32)

    def command_action(
        self,
        action: np.ndarray,
        current_full_state: np.ndarray,
        scope: str,
        max_arm_step: float,
        max_hand_step: float,
    ) -> dict[str, bool]:
        action = np.asarray(action, dtype=np.float32)
        current = np.asarray(current_full_state, dtype=np.float32)
        if action.shape != (26,) or current.shape != (36,):
            raise ValueError(f"Invalid action/state shapes: {action.shape}, {current.shape}")
        if not np.isfinite(action).all() or not np.isfinite(current).all():
            raise ValueError("Non-finite action or current state")

        # The exported LinkerArmA7 class owns JOINT_LIMITS, while the factory
        # instance is an ArmClient without those constants.
        left_slewed = self._slew(action[0:7], current[0:7], max_arm_step)
        right_slewed = self._slew(action[7:14], current[7:14], max_arm_step)
        left_arm = np.clip(
            left_slewed, self._arm_limits[:, 0], self._arm_limits[:, 1]
        ).astype(np.float32)
        right_arm = np.clip(
            right_slewed, self._arm_limits[:, 0], self._arm_limits[:, 1]
        ).astype(np.float32)
        self.last_command_diagnostics = {
            "left_arm_clipped_joints": int(
                np.count_nonzero(np.abs(left_arm - left_slewed) > 1e-6)
            ),
            "right_arm_clipped_joints": int(
                np.count_nonzero(np.abs(right_arm - right_slewed) > 1e-6)
            ),
            "left_arm_max_clip_rad": float(np.max(np.abs(left_arm - left_slewed))),
            "right_arm_max_clip_rad": float(
                np.max(np.abs(right_arm - right_slewed))
            ),
        }
        all_devices = {"left_arm", "right_arm", "left_hand", "right_hand"}
        aliases = {
            "arms": {"left_arm", "right_arm"},
            "both_hands": {"left_hand", "right_hand"},
            "full": set(all_devices),
        }
        if scope in aliases:
            selected = aliases[scope]
        else:
            selected = set(scope.split("+"))
        if not selected or not selected.issubset(all_devices):
            raise ValueError(f"Invalid command scope: {scope!r}")
        if "left_arm" not in selected:
            self.last_command_diagnostics["left_arm_clipped_joints"] = 0
            self.last_command_diagnostics["left_arm_max_clip_rad"] = 0.0
        if "right_arm" not in selected:
            self.last_command_diagnostics["right_arm_clipped_joints"] = 0
            self.last_command_diagnostics["right_arm_max_clip_rad"] = 0.0

        commands: list[tuple[str, object, np.ndarray]] = []
        if "left_arm" in selected:
            commands.append(("left_arm", self.left_arm, left_arm))
        if "right_arm" in selected:
            commands.append(("right_arm", self.right_arm, right_arm))
        if "left_hand" in selected:
            left_hand = self._expand_hand_target(
                action[14:20],
                current[14:25],
                self._left_hand_limits,
                self._left_hand_drive,
                max_hand_step,
            )
            commands.append(("left_hand", self.left_hand, left_hand))
        if "right_hand" in selected:
            right_hand = self._expand_hand_target(
                action[20:26],
                current[25:36],
                self._right_hand_limits,
                self._right_hand_drive,
                max_hand_step,
            )
            commands.append(("right_hand", self.right_hand, right_hand))
        self.last_command_diagnostics["command_scope"] = scope
        self.last_command_diagnostics["selected_devices"] = sorted(selected)

        executor = getattr(self, "_command_executor", None)
        if executor is None:
            executor = concurrent.futures.ThreadPoolExecutor(
                max_workers=4,
                thread_name_prefix="rabo-command",
            )
            self._command_executor = executor
        futures = {
            name: executor.submit(
                device.move_joints,
                target.tolist(),
                blocking=True,
            )
            for name, device, target in commands
        }
        results: dict[str, bool] = {}
        for name, future in futures.items():
            try:
                results[name] = bool(future.result(timeout=SDK_COMMAND_TIMEOUT_S))
            except concurrent.futures.TimeoutError as exc:
                for pending in futures.values():
                    pending.cancel()
                raise RuntimeError(
                    f"SDK blocking command timed out after "
                    f"{SDK_COMMAND_TIMEOUT_S:.1f}s: device={name}, "
                    f"scope={scope!r}"
                ) from exc
        if not all(results.values()):
            self.stop()
            raise RuntimeError(f"SDK rejected command: {results}")
        return results

    def stop(self) -> None:
        for device in (
            self.left_arm,
            self.right_arm,
            self.left_hand,
            self.right_hand,
        ):
            try:
                device.stop()
            except Exception as exc:
                print(f"[stop-warning] {type(device).__name__}: {exc!r}", flush=True)

    def shutdown(self) -> None:
        executor = getattr(self, "_command_executor", None)
        if executor is not None:
            executor.shutdown(wait=True, cancel_futures=True)
            self._command_executor = None
        for device in (
            self.left_arm,
            self.right_arm,
            self.left_hand,
            self.right_hand,
        ):
            try:
                device.shutdown()
            except Exception as exc:
                print(f"[shutdown-warning] {type(device).__name__}: {exc!r}", flush=True)




