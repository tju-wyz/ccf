from __future__ import annotations

import sys
import threading
from pathlib import Path
from types import SimpleNamespace

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from agents.rabo_hierarchy_agent.controller import (  # noqa: E402
    LEFT_PREFORM_TARGET,
    HierarchyController,
)
from drivers.rabo_devices import RaboDevices  # noqa: E402


class FakeHand:
    def __init__(self, events: list[tuple]) -> None:
        self.events = events
        self.state = np.zeros(11, dtype=np.float32)

    def move_joints(self, target, blocking=True):
        self.state = np.asarray(target, dtype=np.float32)
        self.events.append(("hand", tuple(target), blocking))
        return True

    def get_joint_angles(self):
        return self.state.tolist()


def test_preform_occurs_after_open_hand_approach() -> None:
    events: list[tuple] = []
    action_state = np.zeros(26, dtype=np.float32)
    full_state = np.zeros(36, dtype=np.float32)
    reference = np.zeros((4, 26), dtype=np.float32)
    reference[:, 0] = [0.0, 0.02, 0.04, 0.06]
    reference[2:, 14:20] = 0.1

    class FakeDevices:
        def __init__(self) -> None:
            self.left_hand = FakeHand(events)
            self.last_command_diagnostics = {}

        def command_action(
            self,
            action,
            current_full_state,
            scope,
            max_arm_step,
            max_hand_step,
        ):
            action_state[:] = action
            full_state[:14] = action[:14]
            events.append(("arm", round(float(action[0]), 3), scope))
            return {"left_arm": True}

    controller = HierarchyController.__new__(HierarchyController)
    controller.devices = FakeDevices()
    controller.policy = SimpleNamespace(
        camera_names=["cam_high", "cam_left_wrist", "cam_right_wrist"]
    )
    controller.reference_trajectories = {
        "left_fine_approach_B": reference,
    }
    controller.stop_event = threading.Event()
    controller._json = lambda *_args, **_kwargs: None
    controller._sample = lambda _dt: SimpleNamespace(
        state=action_state.copy(),
        full_state=full_state.copy(),
        sim_time=1.0,
        image_stamps={
            "cam_high": 0.9,
            "cam_left_wrist": 0.9,
            "cam_right_wrist": 0.9,
        },
        camera_reused={
            "cam_high": False,
            "cam_left_wrist": False,
            "cam_right_wrist": False,
        },
    )
    controller._predict = lambda _snapshot, _stage: (
        {
            "action": np.zeros(26, dtype=np.float32),
            "completion_probability": 0.0,
        },
        1.0,
    )
    controller._unsafe_reasons = lambda _snapshot, _ms: (
        [],
        {
            "cam_high": 100.0,
            "cam_left_wrist": 100.0,
            "cam_right_wrist": 100.0,
        },
    )

    controller._run_reference_stage(
        "left_fine_approach_B",
        1,
        np.arange(0, 7, dtype=np.int64),
        0.5,
        preform_after_waypoint=2,
    )

    assert events == [
        ("arm", 0.0, "left_arm"),
        ("arm", 0.02, "left_arm"),
        ("arm", 0.04, "left_arm"),
        ("hand", LEFT_PREFORM_TARGET, True),
        ("arm", 0.06, "left_arm"),
    ]


class FakeArm:
    def __init__(self) -> None:
        self.calls: list[tuple] = []

    def move_joints(self, target, blocking=True):
        self.calls.append((tuple(target), blocking))
        return True

    def stop(self):
        return None


def test_sdk_dispatch_waits_for_arm_motion_completion() -> None:
    devices = RaboDevices.__new__(RaboDevices)
    devices.left_arm = FakeArm()
    devices.right_arm = FakeArm()
    devices.left_hand = SimpleNamespace(stop=lambda: None)
    devices.right_hand = SimpleNamespace(stop=lambda: None)
    devices._arm_limits = np.asarray([[-2.0, 2.0]] * 7, dtype=np.float32)
    devices._command_executor = None
    devices.last_command_diagnostics = {}

    current_full_state = np.zeros(36, dtype=np.float32)
    current_full_state[7] = 3.0
    try:
        results = devices.command_action(
            action=np.zeros(26, dtype=np.float32),
            current_full_state=current_full_state,
            scope="left_arm",
            max_arm_step=0.04,
            max_hand_step=0.08,
        )
        assert results == {"left_arm": True}
        assert devices.left_arm.calls == [
            ((0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0), True),
        ]
        assert devices.last_command_diagnostics["right_arm_clipped_joints"] == 0
        assert devices.last_command_diagnostics["right_arm_max_clip_rad"] == 0.0
    finally:
        if devices._command_executor is not None:
            devices._command_executor.shutdown(wait=True, cancel_futures=True)