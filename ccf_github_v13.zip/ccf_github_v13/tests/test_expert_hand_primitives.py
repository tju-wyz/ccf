from __future__ import annotations

import json
import sys
import threading
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from agents.rabo_hierarchy_agent.controller import (  # noqa: E402
    LEFT_FORCE_HOLD_STAGES,
    LEFT_OPEN_TARGET,
    LEFT_PREFORM_TARGET,
    RIGHT_RELEASE_TARGET,
    RIGHT_THUMB_OPPOSE_TARGET,
    HierarchyController,
    runtime,
)


class FakeHand:
    def __init__(self, name: str, events: list[tuple]) -> None:
        self.name = name
        self.events = events
        self.state = np.zeros(11, dtype=np.float32)

    def move_joints(self, target, blocking=True):
        self.state = np.asarray(target, dtype=np.float32)
        self.events.append(("move", self.name, tuple(target), blocking))
        return True

    def get_joint_angles(self):
        return self.state.tolist()

    def grasp_force(self, strength, fingers=None, blocking=True):
        self.events.append(
            (
                "force",
                self.name,
                strength,
                None if fingers is None else tuple(fingers),
                blocking,
            )
        )
        return True

    def get_joint_forces(self):
        return [0.1] * 11


def make_controller(events: list[tuple]) -> HierarchyController:
    controller = HierarchyController.__new__(HierarchyController)
    controller.stop_event = threading.Event()
    controller.devices = SimpleNamespace(
        left_hand=FakeHand("left_hand", events),
        right_hand=FakeHand("right_hand", events),
    )
    controller.policy = SimpleNamespace(
        camera_names=["cam_high", "cam_left_wrist", "cam_right_wrist"],
        stages={
            0: {"active_indices": list(range(0, 7)) + list(range(14, 20))}
        },
        stage_to_id={"left_fine_approach_B": 0, "release_B": 0},
    )
    controller._sample = lambda _dt: SimpleNamespace(
        sim_time=1.0,
        image_stamps={
            "cam_high": 0.9,
            "cam_left_wrist": 0.9,
            "cam_right_wrist": 0.9,
        },
        camera_reused={
            "cam_high": False,
            "cam_left_wrist": False,
            "cam_right_wrist": False,
        },
    )
    reference = np.zeros((4, 26), dtype=np.float32)
    reference[:, 0] = [0.0, 0.02, 0.04, 0.06]
    reference[2:, 14:20] = 0.1
    controller.reference_trajectories = {"left_fine_approach_B": reference}
    controller._json = lambda *_args, **_kwargs: None
    return controller


def test_right_grasp_opposes_thumb_before_force() -> None:
    events: list[tuple] = []
    controller = make_controller(events)
    controller._run_expert_grasp_stage("right_grasp_B", 1, 0.5)

    assert events == [
        ("move", "right_hand", RIGHT_THUMB_OPPOSE_TARGET, True),
        ("force", "right_hand", 0.4, (1, 2, 3, 4), True),
    ]


def test_right_grasp_c_uses_all_fingers_after_thumb_opposition() -> None:
    events: list[tuple] = []
    controller = make_controller(events)
    controller._run_expert_grasp_stage("right_grasp_C", 1, 0.5)

    assert events == [
        ("move", "right_hand", RIGHT_THUMB_OPPOSE_TARGET, True),
        ("force", "right_hand", 0.8, None, True),
    ]


def test_right_grasp_does_not_force_when_thumb_misses_target() -> None:
    events: list[tuple] = []
    controller = make_controller(events)
    controller.devices.right_hand.get_joint_angles = lambda: [0.0] * 11

    with pytest.raises(RuntimeError, match="did not reach opposition"):
        controller._run_expert_grasp_stage("right_grasp_B", 1, 0.5)

    assert events == [
        ("move", "right_hand", RIGHT_THUMB_OPPOSE_TARGET, True),
    ]


def test_left_handoff_uses_force_without_position_stream() -> None:
    events: list[tuple] = []
    controller = make_controller(events)
    controller._run_expert_grasp_stage("handoff_B_left_grasp", 1, 0.5)

    assert events == [
        ("force", "left_hand", 1.0, None, True),
    ]


def test_left_carry_refreshes_force_hold_nonblocking() -> None:
    events: list[tuple] = []
    controller = make_controller(events)

    controller._refresh_left_force_hold("place_B", 1)

    assert LEFT_FORCE_HOLD_STAGES == {"place_B", "place_C", "place_A"}
    assert events == [
        ("force", "left_hand", 1.0, None, False),
    ]


def test_hand_targets_are_single_blocking_primitives() -> None:
    events: list[tuple] = []
    controller = make_controller(events)

    controller._run_expert_hand_target_stage(
        "handoff_B_right_release",
        1,
        0.5,
        "right_hand",
        RIGHT_RELEASE_TARGET,
        "release",
    )
    assert events == [
        ("move", "right_hand", RIGHT_RELEASE_TARGET, True),
    ]


def test_release_accepts_sdk_false_within_hand_tolerance() -> None:
    events: list[tuple] = []
    controller = make_controller(events)
    hand = controller.devices.left_hand
    hand.move_joints = lambda _target, blocking=True: False
    hand.get_joint_angles = lambda: [0.1] * 11

    error = controller._command_hand_primitive(
        "left_hand", LEFT_OPEN_TARGET, "release_B:release"
    )

    assert error == pytest.approx(0.1)


@pytest.mark.parametrize(
    ("label", "residual"),
    [
        ("left_fine_approach_B:preform", 0.1),
        ("release_B:release", 0.13),
    ],
)
def test_rejected_nonrelease_or_large_release_error_still_fails(
    label, residual
) -> None:
    events: list[tuple] = []
    controller = make_controller(events)
    hand = controller.devices.left_hand
    hand.move_joints = lambda _target, blocking=True: False
    hand.get_joint_angles = lambda: [residual] * 11

    with pytest.raises(RuntimeError, match="Expert hand primitive rejected"):
        controller._command_hand_primitive(
            "left_hand", LEFT_OPEN_TARGET, label
        )


def test_left_preform_is_scheduled_inside_arm_replay() -> None:
    events: list[tuple] = []
    references: list[tuple] = []
    controller = make_controller(events)

    def record_reference(
        stage, index, active, dt, preform_after_waypoint=None
    ):
        references.append(
            (
                stage,
                index,
                tuple(active.tolist()),
                dt,
                preform_after_waypoint,
            )
        )

    controller._run_reference_stage = record_reference
    controller._run_stage("left_fine_approach_B", 1, 0.5)

    assert events == []
    assert references == [
        ("left_fine_approach_B", 1, tuple(range(7)), 0.5, 2),
    ]


def test_left_release_opens_once_then_replays_only_arm() -> None:
    events: list[tuple] = []
    references: list[tuple] = []
    controller = make_controller(events)

    def record_reference(
        stage, index, active, dt, preform_after_waypoint=None
    ):
        references.append(
            (
                stage,
                index,
                tuple(active.tolist()),
                dt,
                preform_after_waypoint,
            )
        )

    controller._run_reference_stage = record_reference
    controller._run_stage("release_B", 2, 0.5)

    assert events == [
        ("move", "left_hand", LEFT_OPEN_TARGET, True),
    ]
    assert references == [
        ("release_B", 2, tuple(range(7)), 0.5, None),
    ]

def test_primitive_waits_for_a_new_fresh_frame() -> None:
    events: list[tuple] = []
    controller = make_controller(events)
    stale = SimpleNamespace(
        sim_time=2.0,
        image_stamps={
            "cam_high": 0.5,
            "cam_left_wrist": 0.5,
            "cam_right_wrist": 0.5,
        },
        camera_reused={
            "cam_high": True,
            "cam_left_wrist": True,
            "cam_right_wrist": True,
        },
    )
    fresh = SimpleNamespace(
        sim_time=2.0,
        image_stamps={
            "cam_high": 1.9,
            "cam_left_wrist": 1.9,
            "cam_right_wrist": 1.9,
        },
        camera_reused={
            "cam_high": False,
            "cam_left_wrist": False,
            "cam_right_wrist": False,
        },
    )
    snapshots = iter((stale, fresh))
    controller._sample = lambda _dt: next(snapshots)

    snapshot, ages = controller._sample_fresh_for_primitive(
        0.5, "handoff_C_left_grasp"
    )

    assert snapshot is fresh
    assert max(ages.values()) == pytest.approx(100.0)


def test_c_z_calibration_saves_fixed_joint_override(
    tmp_path, monkeypatch
) -> None:
    events: list[tuple] = []
    output = tmp_path / "C_GRASP_Z_MINUS_008_JOINTS.json"
    monkeypatch.setattr(runtime, "C_GRASP_OVERRIDE_PATH", output)

    class FakeRightArm:
        def get_pose(self):
            return ((0.1, 0.2, -0.3), (0.0, 0.8, 0.0))

        def move_to(
            self,
            x,
            y,
            z,
            roll,
            pitch,
            yaw,
            blocking=True,
        ):
            events.append(
                ("move_to", x, y, z, roll, pitch, yaw, blocking)
            )
            return True

        def get_joint_angles(self):
            return [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7]

    controller = make_controller(events)
    controller.devices.right_arm = FakeRightArm()
    controller._run_c_z_calibration()

    assert events == [
        ("move_to", 0.1, 0.2, -0.38, 0.0, 0.8, 0.0, True),
    ]
    payload = json.loads(output.read_text(encoding="utf-8"))
    assert payload["deployment_uses_runtime_object_coordinates"] is False
    assert payload["calibration_offset_xyz_m"] == pytest.approx([0.0, 0.0, -0.08])
    assert payload["joint_angles_rad"] == pytest.approx(
        [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7]
    )
    assert controller.c_grasp_joint_override.tolist() == pytest.approx(
        [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7]
    )


def test_c_joint_override_uses_only_fixed_joint_target() -> None:
    events: list[tuple] = []
    controller = make_controller(events)
    controller.c_grasp_joint_override = np.full(7, 0.12, dtype=np.float32)
    state = np.zeros(26, dtype=np.float32)
    full_state = np.zeros(36, dtype=np.float32)

    def sample(_dt):
        return SimpleNamespace(
            state=state.copy(),
            full_state=full_state.copy(),
            sim_time=1.0,
            image_stamps={
                "cam_high": 0.9,
                "cam_left_wrist": 0.9,
                "cam_right_wrist": 0.9,
            },
            camera_reused={
                "cam_high": False,
                "cam_left_wrist": False,
                "cam_right_wrist": False,
            },
        )

    def command_action(**kwargs):
        state[:] = kwargs["action"]
        full_state[7:14] = kwargs["action"][7:14]
        events.append(
            (
                kwargs["scope"],
                tuple(float(value) for value in kwargs["action"][7:14]),
            )
        )
        return {"right_arm": True}

    controller._sample = sample
    controller._unsafe_reasons = lambda _snapshot, _ms: (
        [],
        {
            "cam_high": 100.0,
            "cam_left_wrist": 100.0,
            "cam_right_wrist": 100.0,
        },
    )
    controller.devices.command_action = command_action
    controller.devices.last_command_diagnostics = {}

    controller._run_c_joint_override(0.5)

    assert events == [
        ("right_arm", pytest.approx((0.12,) * 7)),
    ]

def test_approach_c_runs_calibration_after_reference(
    monkeypatch,
) -> None:
    events: list[tuple] = []
    controller = make_controller(events)
    controller.policy.stages[1] = {
        "active_indices": list(range(7, 14))
    }
    controller.policy.stage_to_id["approach_C"] = 1
    controller.reference_trajectories["approach_C"] = np.zeros(
        (2, 26), dtype=np.float32
    )
    controller.c_grasp_joint_override = None
    controller._run_reference_stage = (
        lambda stage, *_args, **_kwargs: events.append(("reference", stage))
    )
    controller._run_c_z_calibration = lambda: events.append(("calibrate",))
    monkeypatch.setattr(runtime, "CALIBRATE_C_Z", True)

    controller._run_stage("approach_C", 10, 0.5)

    assert events == [
        ("reference", "approach_C"),
        ("calibrate",),
    ]


def test_approach_c_uses_saved_joints_without_calibration(
    monkeypatch,
) -> None:
    events: list[tuple] = []
    controller = make_controller(events)
    controller.policy.stages[1] = {
        "active_indices": list(range(7, 14))
    }
    controller.policy.stage_to_id["approach_C"] = 1
    controller.reference_trajectories["approach_C"] = np.zeros(
        (2, 26), dtype=np.float32
    )
    controller.c_grasp_joint_override = np.zeros(7, dtype=np.float32)
    controller._run_reference_stage = (
        lambda stage, *_args, **_kwargs: events.append(("reference", stage))
    )
    controller._run_c_joint_override = (
        lambda dt: events.append(("fixed_joints", dt))
    )
    controller._run_c_z_calibration = lambda: events.append(("calibrate",))
    monkeypatch.setattr(runtime, "CALIBRATE_C_Z", False)

    controller._run_stage("approach_C", 10, 0.5)

    assert events == [
        ("reference", "approach_C"),
        ("fixed_joints", 0.5),
    ]

def test_a_shift_calibration_saves_grasp_and_lift_joints(
    tmp_path, monkeypatch
) -> None:
    events: list[tuple] = []
    grasp_output = tmp_path / "A_GRASP.json"
    lift_output = tmp_path / "A_LIFT.json"
    monkeypatch.setattr(runtime, "A_GRASP_OVERRIDE_PATH", grasp_output)
    monkeypatch.setattr(runtime, "A_LIFT_OVERRIDE_PATH", lift_output)

    class FakeRightArm:
        def __init__(self):
            self.pose = ((0.1, 0.2, -0.3), (0.0, 0.8, 0.0))
            self.joints = [0.1] * 7

        def get_pose(self):
            return self.pose

        def move_to(
            self,
            x,
            y,
            z,
            roll,
            pitch,
            yaw,
            blocking=True,
        ):
            events.append(
                ("move_to", x, y, z, roll, pitch, yaw, blocking)
            )
            self.pose = ((x, y, z), (roll, pitch, yaw))
            self.joints = [round(value + 0.1, 3) for value in self.joints]
            return True

        def get_joint_angles(self):
            return self.joints

    controller = make_controller(events)
    controller.devices.right_arm = FakeRightArm()

    controller._run_a_y_calibration()
    controller._run_a_lift_calibration()

    assert len(events) == 2
    assert events[0][0] == "move_to"
    assert events[0][1:7] == pytest.approx(
        (0.1, 0.25, -0.3, 0.0, 0.8, 0.0)
    )
    assert events[0][7] is True
    assert events[1][0] == "move_to"
    assert events[1][1:7] == pytest.approx(
        (0.1, 0.25, -0.22, 0.0, 0.8, 0.0)
    )
    assert events[1][7] is True
    grasp = json.loads(grasp_output.read_text(encoding="utf-8"))
    lift = json.loads(lift_output.read_text(encoding="utf-8"))
    assert grasp["calibration_offset_xyz_m"] == pytest.approx(
        [0.0, 0.05, 0.0]
    )
    assert lift["calibration_offset_xyz_m"] == pytest.approx(
        [0.0, 0.0, 0.08]
    )
    assert controller.a_grasp_joint_override.tolist() == pytest.approx(
        [0.2] * 7
    )
    assert controller.a_lift_joint_override.tolist() == pytest.approx(
        [0.3] * 7
    )


def test_shifted_a_lift_resumes_at_nearest_reference_waypoint(
    monkeypatch,
) -> None:
    events: list[tuple] = []
    controller = make_controller(events)
    controller.policy.stages[1] = {
        "active_indices": list(range(14))
    }
    controller.policy.stage_to_id["lift_and_left_approach_A"] = 1
    reference = np.zeros((4, 26), dtype=np.float32)
    reference[:, 7:14] = np.asarray(
        [[0.0] * 7, [0.1] * 7, [0.2] * 7, [0.3] * 7],
        dtype=np.float32,
    )
    controller.reference_trajectories[
        "lift_and_left_approach_A"
    ] = reference
    controller.a_lift_joint_override = np.full(
        7, 0.18, dtype=np.float32
    )
    controller._run_a_lift_joint_override = (
        lambda dt: events.append(("fixed_lift", dt))
    )

    def record_reference(
        stage,
        index,
        active,
        dt,
        preform_after_waypoint=None,
        start_waypoint=0,
    ):
        events.append(
            ("reference", stage, start_waypoint, tuple(active.tolist()))
        )

    controller._run_reference_stage = record_reference
    monkeypatch.setattr(runtime, "CALIBRATE_A_Y", False)

    controller._run_stage("lift_and_left_approach_A", 21, 0.5)

    assert events == [
        ("fixed_lift", 0.5),
        (
            "reference",
            "lift_and_left_approach_A",
            2,
            tuple(range(14)),
        ),
    ]


def test_approach_a_calibrates_after_original_reference(
    monkeypatch,
) -> None:
    events: list[tuple] = []
    controller = make_controller(events)
    controller.policy.stages[1] = {
        "active_indices": list(range(7, 14))
    }
    controller.policy.stage_to_id["approach_A"] = 1
    controller.reference_trajectories["approach_A"] = np.zeros(
        (2, 26), dtype=np.float32
    )
    controller.a_grasp_joint_override = None
    controller._run_reference_stage = (
        lambda stage, *_args, **_kwargs: events.append(("reference", stage))
    )
    controller._run_a_y_calibration = lambda: events.append(
        ("calibrate_a",)
    )
    monkeypatch.setattr(runtime, "CALIBRATE_A_Y", True)

    controller._run_stage("approach_A", 19, 0.5)

    assert events == [
        ("reference", "approach_A"),
        ("calibrate_a",),
    ]


def test_fixed_scene_metadata_moves_a_world_y_minus_005() -> None:
    scene = json.loads(
        (ROOT / "FIXED_SCENE_EPISODE01.json").read_text(encoding="utf-8-sig")
    )
    assert scene["nut_poses"]["A"][1] == pytest.approx(-0.1499)
    assert scene["deployment_policy_uses_object_coordinates"] is False

def test_official_autorun_requires_all_fixed_overrides() -> None:
    assert HierarchyController._should_actuate(True, True, False) is True
    assert HierarchyController._should_actuate(False, True, True) is True
    assert HierarchyController._should_actuate(False, True, False) is False
    assert HierarchyController._should_actuate(False, False, True) is False


def test_official_delay_waits_before_actuation(monkeypatch) -> None:
    controller = HierarchyController.__new__(HierarchyController)
    waits: list[float] = []
    logs: list[tuple[str, dict]] = []
    controller.stop_event = SimpleNamespace(
        wait=lambda seconds: waits.append(seconds) or False
    )
    controller._json = lambda event, **payload: logs.append((event, payload))
    monkeypatch.setattr(runtime, "OFFICIAL_ACTUATION_DELAY_S", 10.0)

    controller._wait_before_actuation()

    assert waits == [10.0]
    assert logs == [("official_actuation_delay", {"seconds": 10.0})]


def test_official_idle_releases_device_action_servers() -> None:
    events: list[str] = []
    controller = HierarchyController.__new__(HierarchyController)
    controller.stop_event = threading.Event()
    controller.stop_event.set()
    controller.devices = SimpleNamespace(
        stop=lambda: events.append("stop"),
        shutdown=lambda: events.append("shutdown"),
    )
    logs: list[tuple[str, dict]] = []
    controller._json = lambda event, **payload: logs.append((event, payload))

    controller._wait_after_official_run("complete")

    assert events == ["stop", "shutdown"]
    assert controller.devices is None
    assert logs[0][0] == "official_run_idle"
    assert logs[0][1]["action_servers_released"] is True
