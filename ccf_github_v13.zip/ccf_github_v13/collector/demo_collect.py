"""demo_collect.py — 力控抓取基线演示采集器（用于诊断螺母粘连）。

复用 RaboNutHandoffTask（sim 模式、随机化关闭 → 固定基准位姿），后台采样线程
并行跑完整 B/C/A 流程。每个采样点记录：
  - 相对 / 墙钟时间戳
  - phase 名称 + 序号（PhaseTracker）
  - 36 维关节角 full_state（task.read_full_state）
  - 22 维手指力矩（左右手各 11 个 force_torque 传感器：torque 模长 + force 模长）
  - 顶部相机视频（默认录制）

运行结束后（Ctrl+C 或流程自然结束）自动保存到
datasets/demo_collect/demo_YYYYmmdd_HHMMSS/：
  states.npz + phases.json + meta.json + video_top.mp4

本脚本只做"读"和"采"，不修改 config.yaml、不改场景、不碰 main.py。
"""

from __future__ import annotations

import argparse
import json
import random
import threading
import time
from pathlib import Path
from typing import Any

import numpy as np

from rabo_collector.config import load_config
from rabo_collector.episode import PhaseTracker
from rabo_collector.sensors import header_stamp_seconds, image_to_bgr8
from rabo_collector.task import RaboNutHandoffTask

# 采样频率：对齐手指 force_torque 传感器的 10Hz update_rate。
SAMPLING_HZ = 10
CAMERA_READY_MIN_FRAMES = 5

# 手指 force_torque topic（顺序：先左手 11 个，再右手 11 个）。
# 顺序与场景中 link 顺序一致，用于把 22 维力矩向量与手指一一对应。
LEFT_FT_TOPICS = [
    "r136d7b_tp_fts_1f92f60733",  # thumb_metacarpals_base2
    "r136d7b_tp_fts_094820dc35",  # thumb_metacarpals
    "r136d7b_tp_fts_8e6c9ec41d",  # thumb_distal
    "r136d7b_tp_fts_2f92dfedbc",  # index_proximal
    "r136d7b_tp_fts_88eebd515e",  # index_distal
    "r136d7b_tp_fts_f3c793771c",  # middle_proximal
    "r136d7b_tp_fts_1fd37302bf",  # middle_distal
    "r136d7b_tp_fts_b94282a9e8",  # ring_proximal
    "r136d7b_tp_fts_2764cf5b12",  # ring_distal
    "r136d7b_tp_fts_cc032bea74",  # pinky_proximal
    "r136d7b_tp_fts_112a748ae9",  # pinky_distal
]
RIGHT_FT_TOPICS = [
    "rcd72e2_tp_fts_3de69eda26",  # thumb_metacarpals_base2
    "rcd72e2_tp_fts_d2a6541a1e",  # thumb_metacarpals
    "rcd72e2_tp_fts_0c06b0dccc",  # thumb_distal
    "rcd72e2_tp_fts_5d58bffa87",  # index_proximal
    "rcd72e2_tp_fts_7d319548fa",  # index_distal
    "rcd72e2_tp_fts_0e0e800e4b",  # middle_proximal
    "rcd72e2_tp_fts_a9202465ea",  # middle_distal
    "rcd72e2_tp_fts_22c267ca12",  # ring_proximal
    "rcd72e2_tp_fts_9955d0acad",  # ring_distal
    "rcd72e2_tp_fts_f918ef8abb",  # pinky_proximal
    "rcd72e2_tp_fts_2c1026959b",  # pinky_distal
]
ALL_FT_TOPICS = LEFT_FT_TOPICS + RIGHT_FT_TOPICS


def _wrench_mags(msg: Any) -> tuple[float, float]:
    """返回 (torque 模长, force 模长)。"""
    fx, fy, fz = msg.force.x, msg.force.y, msg.force.z
    tx, ty, tz = msg.torque.x, msg.torque.y, msg.torque.z
    force = float(np.sqrt(fx * fx + fy * fy + fz * fz))
    torque = float(np.sqrt(tx * tx + ty * ty + tz * tz))
    return torque, force


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="力控抓取基线演示采集（诊断螺母粘连）"
    )
    parser.add_argument("--config", default=str(Path(__file__).with_name("config.yaml")))
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--no-video", action="store_true", help="不录制顶部相机视频")
    return parser.parse_args()


class _DemoRecorder:
    """订阅 FT + 顶部相机，按固定频率采样到内存，最后落盘。"""

    def __init__(self, config, task: RaboNutHandoffTask, phase: PhaseTracker, no_video: bool):
        self.config = config
        self.task = task
        self.phase = phase
        self.no_video = no_video

        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._ft_latest: dict[str, tuple[float, float]] = {}
        self._cam_latest: dict[str, Any] = {}
        self._cam_msg_count = 0

        # 采样结果缓冲
        self._monotonic: list[float] = []
        self._wall: list[float] = []
        self._phase_indices: list[int] = []
        self._phase_names: list[str] = []
        self._full_states: list[np.ndarray] = []
        self._wrench_torque: list[np.ndarray] = []
        self._wrench_force: list[np.ndarray] = []

        self._node = None
        self._executor = None
        self._spin_thread: threading.Thread | None = None
        self._sample_thread: threading.Thread | None = None
        self._video_writer = None
        self._video_path: Path | None = None

    # ── 订阅 ─────────────────────────────────────────────────────────
    def start_subscriptions(self) -> None:
        try:
            import rclpy
            from rclpy.callback_groups import MutuallyExclusiveCallbackGroup
            from rclpy.executors import MultiThreadedExecutor, SingleThreadedExecutor
            from rclpy.qos import (
                DurabilityPolicy,
                HistoryPolicy,
                QoSProfile,
                ReliabilityPolicy,
            )
            from geometry_msgs.msg import Wrench
            from sensor_msgs.msg import Image
        except ImportError as exc:
            raise RuntimeError("演示采集需要 rclpy / sensor_msgs / geometry_msgs") from exc

        if not rclpy.ok():
            rclpy.init(args=None)

        qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=6,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
        )

        self._node = rclpy.create_node("dexora_demo_collect_recorder")

        for topic in ALL_FT_TOPICS:
            group = MutuallyExclusiveCallbackGroup()
            self._node.create_subscription(
                Wrench,
                topic,
                lambda msg, t=topic: self._on_wrench(t, msg),
                qos,
                callback_group=group,
            )

        for name, topic in self.config.camera_topics.items():
            group = MutuallyExclusiveCallbackGroup()
            self._node.create_subscription(
                Image,
                topic,
                lambda msg, n=name: self._on_image(n, msg),
                qos,
                callback_group=group,
            )

        try:
            self._executor = MultiThreadedExecutor(num_threads=2)
        except Exception:
            self._executor = SingleThreadedExecutor()
        self._executor.add_node(self._node)
        self._spin_thread = threading.Thread(
            target=self._executor.spin,
            name="demo-collect-spin",
            daemon=True,
        )
        self._spin_thread.start()

    def _on_wrench(self, topic: str, msg: Any) -> None:
        with self._lock:
            self._ft_latest[topic] = _wrench_mags(msg)

    def _on_image(self, name: str, msg: Any) -> None:
        with self._lock:
            self._cam_latest[name] = msg
            self._cam_msg_count += 1

    def wait_camera_ready(self, timeout_s: float = 30.0) -> None:
        deadline = time.monotonic() + timeout_s
        while True:
            with self._lock:
                ready = self._cam_msg_count >= CAMERA_READY_MIN_FRAMES
            if ready:
                return
            if time.monotonic() > deadline:
                raise TimeoutError(
                    f"等待顶部相机就绪超时（{timeout_s:.1f}s，需≥{CAMERA_READY_MIN_FRAMES}帧）"
                )
            time.sleep(0.05)

    # ── 采样线程 ─────────────────────────────────────────────────────
    def _sample_loop(self) -> None:
        dt = 1.0 / SAMPLING_HZ
        next_tick = time.monotonic()
        while not self._stop_event.is_set():
            now = time.monotonic()

            with self._lock:
                ft_torque = np.full(len(ALL_FT_TOPICS), np.nan, dtype=np.float32)
                ft_force = np.full(len(ALL_FT_TOPICS), np.nan, dtype=np.float32)
                for i, topic in enumerate(ALL_FT_TOPICS):
                    value = self._ft_latest.get(topic)
                    if value is not None:
                        ft_torque[i] = value[0]
                        ft_force[i] = value[1]
                cam_msg = self._cam_latest.get(self.config.primary_camera)

            full_state = self.task.read_full_state()
            if full_state is None:
                full_state = np.full(36, np.nan, dtype=np.float32)
            else:
                full_state = np.asarray(full_state, dtype=np.float32)

            phase_name, phase_index = self.phase.get()

            self._monotonic.append(now)
            self._wall.append(time.time())
            self._phase_indices.append(phase_index)
            self._phase_names.append(phase_name)
            self._full_states.append(full_state)
            self._wrench_torque.append(ft_torque)
            self._wrench_force.append(ft_force)

            if not self.no_video and cam_msg is not None:
                self._write_video_frame(cam_msg)

            next_tick += dt
            remaining = next_tick - time.monotonic()
            if remaining > 0:
                self._stop_event.wait(min(remaining, 0.05))

    def _write_video_frame(self, msg: Any) -> None:
        try:
            frame = image_to_bgr8(msg)
        except Exception:
            return
        width = int(self.config.dataset["image_width"])
        height = int(self.config.dataset["image_height"])
        import cv2

        if frame.shape[1] != width or frame.shape[0] != height:
            frame = cv2.resize(frame, (width, height), interpolation=cv2.INTER_AREA)
        if self._video_writer is None:
            fourcc_name = str(self.config.dataset.get("video_fourcc", "mp4v"))
            self._video_writer = cv2.VideoWriter(
                str(self._video_path),
                cv2.VideoWriter_fourcc(*fourcc_name),
                SAMPLING_HZ,
                (width, height),
            )
            if not self._video_writer.isOpened():
                raise RuntimeError("无法创建视频，请检查 OpenCV/FFmpeg 编码器")
        self._video_writer.write(frame)

    def start(self) -> None:
        self._stop_event.clear()
        self._sample_thread = threading.Thread(
            target=self._sample_loop, name="demo-collect-sample", daemon=True
        )
        self._sample_thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._sample_thread is not None:
            self._sample_thread.join(timeout=5.0)
        if self._video_writer is not None:
            self._video_writer.release()
            self._video_writer = None

    def close_subscriptions(self) -> None:
        try:
            if self._executor is not None:
                self._executor.shutdown()
            if self._node is not None:
                self._node.destroy_node()
        except Exception:
            pass
        self._node = None
        self._executor = None


def main() -> int:
    args = parse_args()
    config = load_config(args.config)
    base_seed = args.seed if args.seed is not None else int(config.collection["seed"])
    rng = random.Random(base_seed)

    phase = PhaseTracker()
    task = RaboNutHandoffTask(config, phase)

    # 输出目录：datasets/demo_collect/demo_YYYYmmdd_HHMMSS/
    stamp = time.strftime("%Y%m%d_%H%M%S")
    out_dir = config.root.parent / "demo_collect" / f"demo_{stamp}"
    out_dir.mkdir(parents=True, exist_ok=False)
    video_path = out_dir / "video_top.mp4"

    recorder = _DemoRecorder(config, task, phase, no_video=args.no_video)
    recorder._video_path = video_path

    print(f"输出目录：{out_dir}")
    print(f"采样频率：{SAMPLING_HZ}Hz，seed={base_seed}，随机化=关闭（固定基准位姿）")
    print("等待顶部相机与 FT 话题就绪……")

    recorder.start_subscriptions()
    recorder.wait_camera_ready(float(config.dataset.get("readiness_timeout_s", 30.0)))

    randomization: dict[str, Any] = {}
    try:
        # 先复位（固定位姿），再启动采样线程，覆盖 reset → run 全过程。
        randomization = task.reset(rng, randomize=False)
        recorder.start()
        print("开始跑完整 B/C/A 流程；Ctrl+C 可随时终止并保存。")
        task.run()
        print("任务流程自然结束。")
    except KeyboardInterrupt:
        print("收到 Ctrl+C，停止任务。")
    finally:
        recorder.stop()
        recorder.close_subscriptions()
        task.shutdown()

    # ── 落盘 ─────────────────────────────────────────────────────────
    n = len(recorder._monotonic)
    if n == 0:
        print("没有采到任何样本，未保存。")
        return 1

    np.savez_compressed(
        out_dir / "states.npz",
        monotonic_times=np.asarray(recorder._monotonic, dtype=np.float64),
        wall_times=np.asarray(recorder._wall, dtype=np.float64),
        phase_indices=np.asarray(recorder._phase_indices, dtype=np.int32),
        full_states=np.asarray(recorder._full_states, dtype=np.float32),
        wrench_torque=np.asarray(recorder._wrench_torque, dtype=np.float32),
        wrench_force=np.asarray(recorder._wrench_force, dtype=np.float32),
    )

    index_to_name: dict[str, str] = {}
    for idx, name in zip(recorder._phase_indices, recorder._phase_names):
        index_to_name.setdefault(str(idx), name)

    phases = {
        "phase_names": recorder._phase_names,
        "phase_index_to_name": index_to_name,
    }
    (out_dir / "phases.json").write_text(
        json.dumps(phases, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    meta = {
        "seed": base_seed,
        "randomize": False,
        "sampling_hz": SAMPLING_HZ,
        "sample_count": n,
        "full_state_dim": 36,
        "wrench_dim": 22,
        "left_ft_topics": LEFT_FT_TOPICS,
        "right_ft_topics": RIGHT_FT_TOPICS,
        "camera": dict(config.camera_topics),
        "randomization": randomization,
        "note": "力矩顺序：先左手11个再右手11个；torque/force 均为模长(N·m / N)。",
    }
    (out_dir / "meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(f"已保存 {n} 个采样点到 {out_dir}")
    print("  - states.npz / phases.json / meta.json" + ("" if args.no_video else " / video_top.mp4"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
